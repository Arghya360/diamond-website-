(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,39287,e=>{"use strict";var t=e.i(43476),a=e.i(71645);e.s(["CrystoSubscribeForm",0,function(){let[e,r]=(0,a.useState)(""),[n,i]=(0,a.useState)(!1);return(0,t.jsxs)("form",{onSubmit:function(t){t.preventDefault(),e&&(alert("Thank you for subscribing!"),r(""))},style:{width:"100%",maxWidth:"680px",margin:"0 auto"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",borderBottom:"1px solid rgba(255, 255, 255, 0.28)",paddingBottom:"8px",gap:"16px"},children:[(0,t.jsx)("input",{type:"email",value:e,onChange:e=>r(e.target.value),placeholder:"Enter your email address",required:!0,"aria-label":"Enter your email address",style:{flex:1,background:"transparent",border:"none",outline:"none",color:"#ffffff",fontSize:"15px",fontFamily:"inherit",padding:"8px 0"}}),(0,t.jsx)("button",{type:"submit",style:{background:"none",border:"none",color:"#ffffff",fontSize:"13px",fontWeight:700,letterSpacing:"1.2px",textTransform:"uppercase",textDecoration:"underline",textUnderlineOffset:"6px",cursor:"pointer",padding:"8px 0",whiteSpace:"nowrap",fontFamily:"inherit"},children:"SUBSCRIBE NOW"})]}),(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"center",gap:"10px",marginTop:"16px",cursor:"pointer",color:"rgba(255, 255, 255, 0.55)",fontSize:"13px"},children:[(0,t.jsx)("input",{type:"checkbox",checked:n,onChange:e=>i(e.target.checked),style:{accentColor:"#ffffff",width:"14px",height:"14px",cursor:"pointer"}}),(0,t.jsx)("span",{children:"I agree to all terms and policies"})]})]})},"ScrollToTop",0,function(){return(0,t.jsx)("button",{onClick:function(){window.scrollTo({top:0,behavior:"smooth"})},"aria-label":"Scroll to top",style:{display:"none"}})},"SocialCircle",0,function({href:e,label:r,children:n}){let[i,o]=(0,a.useState)(!1);return(0,t.jsx)("a",{href:e||"#","aria-label":r,target:"_blank",rel:"noopener noreferrer",onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),style:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:"38px",height:"38px",borderRadius:"50%",border:i?"1px solid #ffffff":"1px solid rgba(255, 255, 255, 0.25)",backgroundColor:i?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.03)",color:"#ffffff",textDecoration:"none",fontSize:"13px",fontWeight:600,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',transition:"all 0.25s ease",flexShrink:0},children:n})}])},69353,e=>{"use strict";var t=e.i(71645);e.s(["default",0,function({scripts:e}){let a=(0,t.useRef)(!1);return(0,t.useEffect)(()=>{a.current||(a.current=!0,t().catch(e=>{console.error(e)}));async function t(){let t=new Set(["TweenMax-min-js","aat.min-js"]),a=e.filter(e=>t.has(e.id)),r=e.filter(e=>!t.has(e.id)),n=r.findIndex(e=>"gemzie-js"===e.id);for(let e of(-1===n?r.push(...a):r.splice(n,0,...a),r))await function(e){if("speculationrules"===e.attribs.type)return Promise.resolve();let t=document.createElement("script");for(let[a,r]of Object.entries(e.attribs))"src"!==a&&"async"!==a&&"defer"!==a&&t.setAttribute(a,r);if(!e.src)return t.textContent=e.code,document.body.appendChild(t),Promise.resolve();t.async=!1;let a=new Promise((a,r)=>{t.addEventListener("load",a,{once:!0}),t.addEventListener("error",()=>{r(Error(`Failed to load legacy script: ${e.src}`))},{once:!0})});return t.src=e.src,document.body.appendChild(t),a}(e);window.dispatchEvent(new Event("load"))}},[e]),null}])},97073,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(74080);let n=[{id:"mi-home",label:"Home",href:"/",hasChildren:!1,children:null},{id:"mi-diamonds",label:"Diamonds",href:"/diamonds",hasChildren:!0,children:[{id:"mi-all-diamonds",label:"All Diamonds",href:"/diamonds"},{id:"mi-pink-diamonds",label:"Pink Diamonds",href:"/diamonds/pink"},{id:"mi-white-diamonds",label:"White Diamonds",href:"/diamonds/white"},{id:"mi-cyo",label:"Create Your Own",href:"/create-your-own"}]},{id:"mi-shop",label:"Shop",href:"/shop",hasChildren:!1,children:null},{id:"mi-wlg",label:"Why Lab Grown",href:"/why-lab-grown",hasChildren:!0,children:[{id:"mi-wlg-overview",label:"Why Lab Grown",href:"/why-lab-grown"},{id:"mi-wlg-guide",label:"Diamond Guide",href:"/diamond-guide"},{id:"mi-wlg-sourcing",label:"Sourcing",href:"/sourcing"}]},{id:"mi-about",label:"About Caritas",href:"/about-us",hasChildren:!1,children:null},{id:"mi-contact",label:"Contact",href:"/contact",hasChildren:!1,children:null}];function i(e,t){return e.href===t||(e.children?e.children.some(e=>e.href===t):!!("/"!==e.href&&"#"!==e.href&&t.startsWith(e.href)))}function o({items:e,parentId:a,currentPath:r}){return(0,t.jsx)("ul",{className:"mega-sub-menu",id:`mega-sub-menu-${a}`,children:e.map(e=>{let a=e.href===r;return(0,t.jsx)("li",{id:e.id,className:`mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page${a?" mega-current-menu-item mega-current_page_item":""}`,children:(0,t.jsx)("a",{className:"mega-menu-link",href:e.href,style:{color:"#ffffff",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",fontWeight:a?700:500,borderRadius:"4px"},children:e.label})},e.id)})})}function m({currentPath:e}){return(0,t.jsx)("ul",{id:"mega-menu-primary",className:"mega-menu max-mega-menu mega-menu-horizontal mega-no-js","data-event":"hover_intent","data-effect":"fade_up","data-effect-speed":"200","data-effect-mobile":"disabled","data-effect-speed-mobile":"0","data-mobile-force-width":"false","data-second-click":"go","data-document-click":"collapse","data-vertical-behaviour":"standard","data-breakpoint":"1024","data-unbind":"true",children:n.map(a=>{let r=i(a,e),n="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom";return a.hasChildren&&(n+=" mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-dropdown"),r&&!a.hasChildren&&(n+=" mega-current-menu-item mega-current_page_item"),r&&a.hasChildren&&(n+=" mega-current-menu-ancestor mega-current-menu-parent"),(0,t.jsxs)("li",{id:a.id,className:n,children:[(0,t.jsxs)("a",{className:"mega-menu-link",href:a.href,style:{color:"#ffffff",backgroundColor:"transparent",fontWeight:r?700:500,display:"inline-flex",alignItems:"center",gap:"6px",position:"relative",zIndex:2,padding:"0 15px"},...a.hasChildren?{"aria-haspopup":"true","aria-expanded":"false","aria-controls":`mega-sub-menu-${a.id}`}:{},children:[(0,t.jsxs)("span",{style:{color:"#ffffff",position:"relative",zIndex:3},children:[a.label,"mi-about"===a.id&&(0,t.jsx)("span",{style:{display:"none"},children:"About Us"})]}),a.hasChildren&&(0,t.jsx)("span",{className:"mega-indicator","aria-hidden":"true",style:{color:"#ffffff",position:"relative",zIndex:3}})]}),a.hasChildren&&(0,t.jsx)(o,{items:a.children,parentId:a.id,currentPath:e})]},a.id)})})}function l({items:e,open:a,currentPath:r,onNavigate:n}){return(0,t.jsx)("ul",{style:{listStyle:"none",padding:"0 0 0 16px",margin:"4px 0 8px 16px",display:a?"block":"none",borderLeft:"2px solid var(--primary-color, #BFA37C)"},children:e.map(e=>{let a=e.href===r;return(0,t.jsx)("li",{children:(0,t.jsx)("a",{href:e.href,onClick:n,style:{display:"block",padding:"10px 16px",margin:"4px 0",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"4px",textDecoration:"none",fontSize:"14px",fontWeight:a?700:500},children:e.label})},e.id)})})}function s({open:e,onClose:o,currentPath:m}){let[p,c]=(0,a.useState)(!1),[d,u]=(0,a.useState)(null);return((0,a.useEffect)(()=>{c(!0)},[]),(0,a.useEffect)(()=>{if(e){let e=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=e}}},[e]),p&&e)?(0,r.createPortal)((0,t.jsxs)("div",{id:"custom-mobile-drawer",role:"dialog","aria-modal":"true","aria-label":"Mobile Navigation",style:{position:"fixed",top:0,left:0,right:0,bottom:0,width:"100vw",height:"100vh",height:"100dvh",zIndex:0x7fffffff,backgroundColor:"#0C1315",overflowY:"auto",WebkitOverflowScrolling:"touch",paddingTop:"max(20px, env(safe-area-inset-top, 20px))",paddingBottom:"max(28px, env(safe-area-inset-bottom, 28px))",paddingLeft:"max(16px, env(safe-area-inset-left, 16px))",paddingRight:"max(16px, env(safe-area-inset-right, 16px))",boxSizing:"border-box",display:"flex",flexDirection:"column"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px 18px",borderBottom:"1px solid rgba(255, 255, 255, 0.08)",flexShrink:0},children:[(0,t.jsx)("a",{href:"/",onClick:o,style:{display:"inline-flex",alignItems:"center"},children:(0,t.jsx)("img",{src:"/wp-content/uploads/2024/03/logo-white.png",alt:"Caritas Luxury",style:{height:"34px",width:"auto"}})}),(0,t.jsx)("button",{type:"button",onClick:o,"aria-label":"Close menu",style:{background:"rgba(255, 255, 255, 0.08)",border:"none",borderRadius:"50%",cursor:"pointer",color:"#ffffff",fontSize:"22px",lineHeight:1,width:"40px",height:"40px",display:"flex",alignItems:"center",justifyContent:"center"},children:"✕"})]}),(0,t.jsx)("ul",{style:{listStyle:"none",padding:"16px 0",margin:0,flex:"1 0 auto"},children:n.map(e=>{let a=i(e,m),r=d===e.id;return(0,t.jsxs)("li",{style:{borderBottom:"1px solid rgba(255, 255, 255, 0.06)"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"6px 8px"},children:[(0,t.jsxs)("a",{href:e.href,onClick:t=>{e.hasChildren?(t.preventDefault(),u(r?null:e.id)):o()},style:{flex:1,display:"block",padding:"12px 14px",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"6px",textDecoration:"none",fontSize:"17px",fontWeight:a?700:500,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)'},children:[e.label,"mi-about"===e.id&&(0,t.jsx)("span",{style:{display:"none"},children:"About Us"})]}),e.hasChildren&&(0,t.jsx)("button",{type:"button",onClick:()=>u(r?null:e.id),"aria-expanded":r,"aria-label":`Toggle ${e.label} sub-menu`,style:{background:"none",border:"none",color:"#ffffff",fontSize:"24px",padding:"10px 16px",cursor:"pointer",lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"},children:r?"−":"+"})]}),e.hasChildren&&(0,t.jsx)(l,{items:e.children,open:r,currentPath:m,onNavigate:o})]},e.id)})}),(0,t.jsx)("div",{style:{padding:"20px 8px 16px",marginTop:"auto",flexShrink:0},children:(0,t.jsx)("a",{href:"/contact",onClick:o,style:{display:"block",textAlign:"center",padding:"14px 20px",backgroundColor:"var(--primary-color, #BFA37C)",color:"#ffffff",borderRadius:"8px",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',fontSize:"16px",fontWeight:700,letterSpacing:"0.5px",textDecoration:"none"},children:"Get In Touch"})})]}),document.body):null}e.s(["default",0,function({currentPath:e="/"}){let[r,n]=(0,a.useState)(!1);return(0,a.useEffect)(()=>(document.body.style.overflow=r?"hidden":"",()=>{document.body.style.overflow=""}),[r]),(0,a.useEffect)(()=>{let e=e=>{e.target.closest(".menu-toggle, .pt-toggle-btn")&&(e.preventDefault(),e.stopPropagation(),n(!0))};return document.addEventListener("click",e),()=>document.removeEventListener("click",e)},[]),(0,t.jsxs)("div",{id:"mega-menu-wrap-primary",className:"mega-menu-wrap",children:[(0,t.jsx)("style",{children:`
        /* Desktop dropdown styling and animation */
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children {
            position: relative;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children > ul.mega-sub-menu {
            display: none !important;
            position: absolute !important;
            top: 100% !important;
            left: 0 !important;
            min-width: 220px !important;
            background-color: #0C1315 !important;
            padding: 12px 8px !important;
            margin: 0 !important;
            border-radius: 6px !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.35) !important;
            z-index: 99999 !important;
            list-style: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:hover > ul.mega-sub-menu,
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:focus-within > ul.mega-sub-menu {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item {
            display: block !important;
            width: 100% !important;
            margin-bottom: 4px !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link {
            display: block !important;
            padding: 10px 18px !important;
            color: #ffffff !important;
            font-size: 14px !important;
            text-decoration: none !important;
            white-space: nowrap !important;
            border-radius: 4px !important;
            transition: all 0.2s ease !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover,
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-current-menu-item > a.mega-menu-link {
            background-color: var(--primary-color, #BFA37C) !important;
            color: #ffffff !important;
            font-weight: 700 !important;
          }
        }

        /* Top-level menu links – always white text so it is 100% visible inside the #BEA37C box */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-page-ancestor > a.mega-menu-link {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
          text-decoration: none !important;
          position: relative !important;
          z-index: 2 !important;
        }

        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link * {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
        }

        /* Ensure top-level a.mega-menu-link has transparent background so ONLY the 40px :before pill is visible */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link {
          background: transparent !important;
          background-color: transparent !important;
          border-radius: 0 !important;
        }

        /* The #BEA37C pill box is strictly rendered by :before so its size is 100% identical on hover and selected page */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:before {
          content: "" !important;
          position: absolute !important;
          top: 50% !important;
          transform: translateY(-50%) !important;
          height: 40px !important;
          border-radius: 6px !important;
          background: var(--primary-color, #BFA37C) !important;
          z-index: 1 !important;
          transition: width 0.25s ease, left 0.25s ease, opacity 0.25s ease !important;
        }

        /* Inactive items: box collapsed */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item:not(.mega-current-menu-item):not(.mega-current-menu-ancestor):not(.mega-current-page-ancestor) > a.mega-menu-link:not(:hover):before {
          width: 0 !important;
          left: 50% !important;
          opacity: 0 !important;
        }

        /* Hovered or selected/active: exact same 40px pill size */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link:before {
          width: 100% !important;
          left: 0 !important;
          height: 40px !important;
          opacity: 1 !important;
        }

        /* Mobile vs Desktop Display Rules */
        @media (max-width: 1023px) {
          /* Strictly hide desktop horizontal menu on mobile so it cannot conflict with mobile drawer */
          #mega-menu-wrap-primary #mega-menu-primary {
            display: none !important;
            visibility: hidden !important;
            pointer-events: none !important;
            position: absolute !important;
            left: -9999px !important;
            width: 0 !important;
            height: 0 !important;
            opacity: 0 !important;
            background: transparent !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            background: transparent !important;
            min-width: 44px !important;
            min-height: 44px !important;
            padding: 8px !important;
            z-index: 100 !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle:after,
          #mega-menu-wrap-primary .mega-menu-toggle.mega-menu-open:after {
            display: none !important;
            content: none !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-box {
            width: 30px !important;
            height: 22px !important;
            display: inline-block !important;
            position: relative !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::before,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::after {
            display: block !important;
            width: 30px !important;
            height: 3px !important;
            background-color: #ffffff !important;
            border-radius: 2px !important;
            position: absolute !important;
            left: 0 !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner {
            top: 50% !important;
            transform: translateY(-50%) !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::before {
            content: "" !important;
            top: -8px !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::after {
            content: "" !important;
            top: 8px !important;
          }
        }
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary {
            display: flex !important;
          }
        }
      `}),(0,t.jsxs)("div",{className:"mega-menu-toggle",onClickCapture:e=>{e.preventDefault(),e.stopPropagation(),n(!0)},children:[(0,t.jsx)("div",{className:"mega-toggle-blocks-left"}),(0,t.jsx)("div",{className:"mega-toggle-blocks-center"}),(0,t.jsx)("div",{className:"mega-toggle-blocks-right",children:(0,t.jsx)("div",{className:"mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-0",id:"mega-toggle-block-0",children:(0,t.jsx)("button",{className:"mega-toggle-animated mega-toggle-animated-slider",type:"button","aria-controls":"mega-menu-primary","aria-expanded":r,"aria-haspopup":"true","aria-label":"Toggle Menu",onClick:e=>{e.preventDefault(),e.stopPropagation(),n(!0)},children:(0,t.jsx)("span",{className:"mega-toggle-animated-box",children:(0,t.jsx)("span",{className:"mega-toggle-animated-inner"})})})})})]}),(0,t.jsx)(m,{currentPath:e}),(0,t.jsx)(s,{open:r,onClose:()=>n(!1),currentPath:e})]})}])},41715,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let r=[{id:"store",label:"DIAMOND ENQUIRY"},{id:"appointment",label:"REQUEST A CONSULTATION"},{id:"service",label:"BESPOKE DESIGN"}];e.s(["default",0,function(){let[e,n]=(0,a.useState)("store"),[i,o]=(0,a.useState)(!1),[m,l]=(0,a.useState)({fullName:"",email:"",phone:"",subject:"",message:"",saveInfo:!1}),[s,p]=(0,a.useState)({showroom:"Private Consultation",name:"",email:"",phone:"",shoppingFor:"",preferredTime:"",shoppedPreviously:"yes",salesAssociate:"",contactPreference:"",message:"",saveInfo:!1}),[c,d]=(0,a.useState)({fullName:"",showroom:"Private Consultation",phone:"",email:"",purchasedFromUs:"yes",accountName:"",serviceDescription:"",saveInfo:!1});function u(e){e.preventDefault(),o(!0),setTimeout(()=>o(!1),5e3)}return(0,t.jsxs)("div",{className:"crysto-form-wrapper",children:[(0,t.jsx)("style",{children:`
        /* Reset any conflicting WordPress legacy styles inside this form */
        .crysto-form-wrapper * {
          box-sizing: border-box !important;
        }
        .crysto-form-wrapper input,
        .crysto-form-wrapper select,
        .crysto-form-wrapper textarea {
          float: none !important;
          box-shadow: none !important;
        }

        .crysto-tabs-bar {
          display: flex !important;
          align-items: flex-end !important;
          justify-content: center !important;
          border-bottom: 1.5px solid #111111 !important;
          margin-bottom: 40px !important;
          gap: 28px !important;
          flex-wrap: wrap !important;
          width: 100% !important;
        }

        .crysto-tab-btn {
          border: none !important;
          background: transparent !important;
          font-size: 13px !important;
          font-weight: 700 !important;
          letter-spacing: 0.6px !important;
          text-transform: uppercase !important;
          cursor: pointer !important;
          padding: 13px 26px !important;
          color: #111111 !important;
          border-radius: 6px 6px 0 0 !important;
          margin-bottom: -1px !important;
          font-family: var(--title-fonts, "Readex Pro", sans-serif) !important;
          transition: all 0.2s ease !important;
        }

        .crysto-tab-btn.active {
          background-color: #000000 !important;
          color: #ffffff !important;
        }

        .crysto-grid-2 {
          display: grid !important;
          grid-template-columns: 1fr 1fr !important;
          gap: 22px 28px !important;
          margin-bottom: 22px !important;
          width: 100% !important;
          clear: both !important;
        }

        .crysto-grid-3 {
          display: grid !important;
          grid-template-columns: 1fr 1fr 1fr !important;
          gap: 22px 28px !important;
          margin-bottom: 22px !important;
          width: 100% !important;
          clear: both !important;
        }

        @media (max-width: 900px) {
          .crysto-grid-3 {
            grid-template-columns: 1fr 1fr !important;
          }
        }

        @media (max-width: 650px) {
          .crysto-grid-2,
          .crysto-grid-3 {
            grid-template-columns: 1fr !important;
          }
          .crysto-tabs-bar {
            flex-direction: column !important;
            align-items: stretch !important;
            gap: 8px !important;
          }
          .crysto-tab-btn {
            border-radius: 6px !important;
            text-align: center !important;
          }
          .crysto-bottom-action-row {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 16px !important;
          }
        }

        .crysto-label {
          display: block !important;
          font-size: 14px !important;
          font-weight: 700 !important;
          color: #111111 !important;
          margin-bottom: 8px !important;
          font-family: var(--title-fonts, "Readex Pro", sans-serif) !important;
          line-height: 1.3 !important;
        }

        .crysto-input {
          width: 100% !important;
          float: none !important;
          display: block !important;
          height: 48px !important;
          padding: 10px 16px !important;
          font-size: 14px !important;
          color: #222222 !important;
          background-color: #fafafa !important;
          border: 1px solid #dcdcdc !important;
          border-radius: 6px !important;
          outline: none !important;
          box-sizing: border-box !important;
          font-family: inherit !important;
          line-height: 28px !important;
          transition: border-color 0.2s, background-color 0.2s !important;
        }

        .crysto-input:focus {
          border-color: #000000 !important;
          background-color: #ffffff !important;
        }

        .crysto-select {
          width: 100% !important;
          float: none !important;
          display: block !important;
          height: 48px !important;
          padding: 10px 16px !important;
          font-size: 14px !important;
          color: #222222 !important;
          background-color: #fafafa !important;
          border: 1px solid #dcdcdc !important;
          border-radius: 6px !important;
          outline: none !important;
          box-sizing: border-box !important;
          font-family: inherit !important;
          cursor: pointer !important;
        }

        .crysto-select:focus {
          border-color: #000000 !important;
          background-color: #ffffff !important;
        }

        .crysto-textarea-block {
          clear: both !important;
          margin-bottom: 24px !important;
          display: block !important;
          width: 100% !important;
        }

        .crysto-textarea {
          width: 100% !important;
          float: none !important;
          display: block !important;
          min-height: 160px !important;
          padding: 14px 16px !important;
          background-color: #fafafa !important;
          border: 1px solid #dcdcdc !important;
          border-radius: 6px !important;
          font-size: 14px !important;
          color: #222222 !important;
          outline: none !important;
          resize: vertical !important;
          line-height: 1.6 !important;
          box-sizing: border-box !important;
          font-family: inherit !important;
          transition: border-color 0.2s, background-color 0.2s !important;
        }

        .crysto-textarea:focus {
          border-color: #000000 !important;
          background-color: #ffffff !important;
        }

        .crysto-bottom-action-row {
          clear: both !important;
          display: flex !important;
          align-items: center !important;
          flex-wrap: wrap !important;
          gap: 24px !important;
          margin-top: 24px !important;
          width: 100% !important;
        }

        .crysto-submit-btn {
          float: none !important;
          display: inline-flex !important;
          align-items: center !important;
          justify-content: center !important;
          background-color: #ff5400 !important;
          color: #ffffff !important;
          padding: 15px 32px !important;
          font-size: 13px !important;
          font-weight: 700 !important;
          letter-spacing: 0.6px !important;
          text-transform: uppercase !important;
          border: none !important;
          border-radius: 4px !important;
          cursor: pointer !important;
          flex-shrink: 0 !important;
          line-height: 1 !important;
          font-family: inherit !important;
          transition: background-color 0.2s ease !important;
        }

        .crysto-submit-btn:hover {
          background-color: #e04a00 !important;
        }

        .crysto-consent-label {
          display: inline-flex !important;
          align-items: center !important;
          gap: 10px !important;
          font-size: 13px !important;
          color: #666666 !important;
          cursor: pointer !important;
          margin: 0 !important;
          line-height: 1.5 !important;
        }

        .crysto-circle-checkbox {
          appearance: none !important;
          -webkit-appearance: none !important;
          width: 17px !important;
          height: 17px !important;
          border: 1.5px solid #b5b5b5 !important;
          border-radius: 50% !important;
          outline: none !important;
          cursor: pointer !important;
          display: inline-block !important;
          position: relative !important;
          flex-shrink: 0 !important;
          background-color: #ffffff !important;
          margin: 0 !important;
          padding: 0 !important;
          vertical-align: middle !important;
        }

        .crysto-circle-checkbox:checked {
          border-color: #ff5400 !important;
          background-color: #ff5400 !important;
        }

        .crysto-circle-checkbox:checked::after {
          content: "" !important;
          display: block !important;
          width: 7px !important;
          height: 7px !important;
          border-radius: 50% !important;
          background-color: #ffffff !important;
          position: absolute !important;
          top: 50% !important;
          left: 50% !important;
          transform: translate(-50%, -50%) !important;
        }

        .crysto-radio-group {
          display: flex !important;
          gap: 24px !important;
          align-items: center !important;
          height: 48px !important;
        }

        .crysto-radio-label {
          display: inline-flex !important;
          align-items: center !important;
          gap: 8px !important;
          cursor: pointer !important;
          font-size: 14px !important;
          color: #222222 !important;
          margin: 0 !important;
        }

        .crysto-radio-label input[type="radio"] {
          margin: 0 !important;
          width: 16px !important;
          height: 16px !important;
          accent-color: #0070f3 !important;
          cursor: pointer !important;
        }
      `}),(0,t.jsx)("div",{className:"crysto-tabs-bar",children:r.map(a=>{let r=e===a.id;return(0,t.jsx)("button",{type:"button",className:`crysto-tab-btn ${r?"active":""}`,onClick:()=>n(a.id),children:a.label},a.id)})}),i&&(0,t.jsx)("div",{style:{padding:"16px 20px",backgroundColor:"#d4edda",color:"#155724",borderRadius:"6px",marginBottom:"24px",fontSize:"14px",fontWeight:600},children:"Thank you for contacting Caritas Luxury. Your enquiry has been received. Our team will review your details and follow up with you."}),"store"===e&&(0,t.jsxs)("form",{onSubmit:u,children:[(0,t.jsxs)("div",{className:"crysto-grid-2",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Full name*"}),(0,t.jsx)("input",{type:"text",required:!0,className:"crysto-input",placeholder:"Enter your name",value:m.fullName,onChange:e=>l({...m,fullName:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Email address*"}),(0,t.jsx)("input",{type:"email",required:!0,className:"crysto-input",placeholder:"Enter email address",value:m.email,onChange:e=>l({...m,email:e.target.value})})]})]}),(0,t.jsxs)("div",{className:"crysto-grid-2",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Phone number*"}),(0,t.jsx)("input",{type:"tel",required:!0,className:"crysto-input",placeholder:"Enter phone number",value:m.phone,onChange:e=>l({...m,phone:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Subject"}),(0,t.jsx)("input",{type:"text",className:"crysto-input",placeholder:"Enter your subject",value:m.subject,onChange:e=>l({...m,subject:e.target.value})})]})]}),(0,t.jsxs)("div",{className:"crysto-textarea-block",children:[(0,t.jsx)("label",{className:"crysto-label",children:"How can we help you?*"}),(0,t.jsx)("textarea",{required:!0,className:"crysto-textarea",placeholder:"Type here...",value:m.message,onChange:e=>l({...m,message:e.target.value})})]}),(0,t.jsxs)("div",{className:"crysto-bottom-action-row",children:[(0,t.jsx)("button",{type:"submit",className:"crysto-submit-btn",children:"SEND YOUR MESSAGE"}),(0,t.jsxs)("label",{className:"crysto-consent-label",children:[(0,t.jsx)("input",{type:"checkbox",className:"crysto-circle-checkbox",checked:m.saveInfo,onChange:e=>l({...m,saveInfo:e.target.checked})}),(0,t.jsx)("span",{children:"Save my name, email, and website in this browser for the next time I comment."})]})]})]}),"appointment"===e&&(0,t.jsxs)("form",{onSubmit:u,children:[(0,t.jsxs)("div",{className:"crysto-grid-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Select a Showroom *"}),(0,t.jsxs)("select",{required:!0,className:"crysto-select",value:s.showroom,onChange:e=>p({...s,showroom:e.target.value}),children:[(0,t.jsx)("option",{value:"Private Consultation",children:"Private Consultation"}),(0,t.jsx)("option",{value:"New York, NY",children:"New York, NY"}),(0,t.jsx)("option",{value:"Los Angeles, CA",children:"Los Angeles, CA"}),(0,t.jsx)("option",{value:"Melbourne, Australia",children:"Melbourne, Australia"})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"First & Last name*"}),(0,t.jsx)("input",{type:"text",required:!0,className:"crysto-input",placeholder:"Enter your name",value:s.name,onChange:e=>p({...s,name:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Email address*"}),(0,t.jsx)("input",{type:"email",required:!0,className:"crysto-input",placeholder:"Enter email address",value:s.email,onChange:e=>p({...s,email:e.target.value})})]})]}),(0,t.jsxs)("div",{className:"crysto-grid-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Phone number*"}),(0,t.jsx)("input",{type:"tel",required:!0,className:"crysto-input",placeholder:"Enter phone number",value:s.phone,onChange:e=>p({...s,phone:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Which item(s) are you shopping for? *"}),(0,t.jsx)("input",{type:"text",required:!0,className:"crysto-input",value:s.shoppingFor,onChange:e=>p({...s,shoppingFor:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Preferred appointment Day/Time"}),(0,t.jsx)("input",{type:"text",className:"crysto-input",value:s.preferredTime,onChange:e=>p({...s,preferredTime:e.target.value})})]})]}),(0,t.jsxs)("div",{className:"crysto-grid-3",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Have you shopped with us previously?*"}),(0,t.jsxs)("div",{className:"crysto-radio-group",children:[(0,t.jsxs)("label",{className:"crysto-radio-label",children:[(0,t.jsx)("span",{children:"yes"}),(0,t.jsx)("input",{type:"radio",name:"shoppedPreviously",value:"yes",checked:"yes"===s.shoppedPreviously,onChange:()=>p({...s,shoppedPreviously:"yes"})})]}),(0,t.jsxs)("label",{className:"crysto-radio-label",children:[(0,t.jsx)("span",{children:"no"}),(0,t.jsx)("input",{type:"radio",name:"shoppedPreviously",value:"no",checked:"no"===s.shoppedPreviously,onChange:()=>p({...s,shoppedPreviously:"no"})})]})]})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"If 'Yes' which sales associate did you work with?"}),(0,t.jsx)("input",{type:"text",className:"crysto-input",placeholder:"Enter your subject",value:s.salesAssociate,onChange:e=>p({...s,salesAssociate:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"How do you prefer we contact you? *"}),(0,t.jsx)("input",{type:"text",required:!0,className:"crysto-input",placeholder:"Enter your subject",value:s.contactPreference,onChange:e=>p({...s,contactPreference:e.target.value})})]})]}),(0,t.jsxs)("div",{className:"crysto-textarea-block",children:[(0,t.jsx)("label",{className:"crysto-label",children:"Message"}),(0,t.jsx)("textarea",{className:"crysto-textarea",placeholder:"Enter your message...",value:s.message,onChange:e=>p({...s,message:e.target.value})})]}),(0,t.jsxs)("div",{className:"crysto-bottom-action-row",children:[(0,t.jsx)("button",{type:"submit",className:"crysto-submit-btn",children:"SEND YOUR MESSAGE"}),(0,t.jsxs)("label",{className:"crysto-consent-label",children:[(0,t.jsx)("input",{type:"checkbox",className:"crysto-circle-checkbox",checked:s.saveInfo,onChange:e=>p({...s,saveInfo:e.target.checked})}),(0,t.jsx)("span",{children:"Save my name, email, and website in this browser for the next time I comment."})]})]})]}),"service"===e&&(0,t.jsxs)("form",{onSubmit:u,children:[(0,t.jsxs)("div",{className:"crysto-grid-2",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Full name*"}),(0,t.jsx)("input",{type:"text",required:!0,className:"crysto-input",placeholder:"Enter your name",value:c.fullName,onChange:e=>d({...c,fullName:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Select a Showroom *"}),(0,t.jsxs)("select",{required:!0,className:"crysto-select",value:c.showroom,onChange:e=>d({...c,showroom:e.target.value}),children:[(0,t.jsx)("option",{value:"Private Consultation",children:"Private Consultation"}),(0,t.jsx)("option",{value:"New York, NY",children:"New York, NY"}),(0,t.jsx)("option",{value:"Los Angeles, CA",children:"Los Angeles, CA"}),(0,t.jsx)("option",{value:"Melbourne, Australia",children:"Melbourne, Australia"})]})]})]}),(0,t.jsxs)("div",{className:"crysto-grid-2",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Phone number*"}),(0,t.jsx)("input",{type:"tel",required:!0,className:"crysto-input",placeholder:"Enter phone number",value:c.phone,onChange:e=>d({...c,phone:e.target.value})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"crysto-label",children:"Email address*"}),(0,t.jsx)("input",{type:"email",required:!0,className:"crysto-input",placeholder:"Email address",value:c.email,onChange:e=>d({...c,email:e.target.value})})]})]}),(0,t.jsxs)("div",{style:{clear:"both",marginBottom:"22px"},children:[(0,t.jsx)("label",{className:"crysto-label",children:"Was the item purchased from us? *"}),(0,t.jsxs)("div",{className:"crysto-radio-group",children:[(0,t.jsxs)("label",{className:"crysto-radio-label",children:[(0,t.jsx)("span",{children:"yes"}),(0,t.jsx)("input",{type:"radio",name:"purchasedFromUs",value:"yes",checked:"yes"===c.purchasedFromUs,onChange:()=>d({...c,purchasedFromUs:"yes"})})]}),(0,t.jsxs)("label",{className:"crysto-radio-label",children:[(0,t.jsx)("span",{children:"no"}),(0,t.jsx)("input",{type:"radio",name:"purchasedFromUs",value:"no",checked:"no"===c.purchasedFromUs,onChange:()=>d({...c,purchasedFromUs:"no"})})]})]})]}),(0,t.jsxs)("div",{style:{clear:"both",marginBottom:"22px"},children:[(0,t.jsx)("label",{className:"crysto-label",children:"If 'Yes' to the previous question, what is the name associated with your account/purchase?"}),(0,t.jsx)("input",{type:"text",className:"crysto-input",placeholder:"Name an account",value:c.accountName,onChange:e=>d({...c,accountName:e.target.value})})]}),(0,t.jsxs)("div",{className:"crysto-textarea-block",children:[(0,t.jsx)("label",{className:"crysto-label",children:"Description of services needed (ex: sizing, cleaning, loose diamond, rhodium plating, etc...)*"}),(0,t.jsx)("textarea",{required:!0,className:"crysto-textarea",placeholder:"Type here...",value:c.serviceDescription,onChange:e=>d({...c,serviceDescription:e.target.value})})]}),(0,t.jsxs)("div",{className:"crysto-bottom-action-row",children:[(0,t.jsx)("button",{type:"submit",className:"crysto-submit-btn",children:"SEND YOUR MESSAGE"}),(0,t.jsxs)("label",{className:"crysto-consent-label",children:[(0,t.jsx)("input",{type:"checkbox",className:"crysto-circle-checkbox",checked:c.saveInfo,onChange:e=>d({...c,saveInfo:e.target.checked})}),(0,t.jsx)("span",{children:"Save my name, email, and website in this browser for the next time I comment."})]})]})]})]})}])}]);