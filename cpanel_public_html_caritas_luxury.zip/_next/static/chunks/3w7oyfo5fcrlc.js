(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,39287,e=>{"use strict";var a=e.i(43476),n=e.i(71645);e.s(["CrystoSubscribeForm",0,function(){let[e,r]=(0,n.useState)(""),[i,t]=(0,n.useState)(!1);return(0,a.jsxs)("form",{onSubmit:function(a){a.preventDefault(),e&&(alert("Thank you for subscribing!"),r(""))},style:{width:"100%",maxWidth:"680px",margin:"0 auto"},children:[(0,a.jsxs)("div",{style:{display:"flex",alignItems:"center",borderBottom:"1px solid rgba(255, 255, 255, 0.28)",paddingBottom:"8px",gap:"16px"},children:[(0,a.jsx)("input",{type:"email",value:e,onChange:e=>r(e.target.value),placeholder:"Enter your email address",required:!0,"aria-label":"Enter your email address",style:{flex:1,background:"transparent",border:"none",outline:"none",color:"#ffffff",fontSize:"15px",fontFamily:"inherit",padding:"8px 0"}}),(0,a.jsx)("button",{type:"submit",style:{background:"none",border:"none",color:"#ffffff",fontSize:"13px",fontWeight:700,letterSpacing:"1.2px",textTransform:"uppercase",textDecoration:"underline",textUnderlineOffset:"6px",cursor:"pointer",padding:"8px 0",whiteSpace:"nowrap",fontFamily:"inherit"},children:"SUBSCRIBE NOW"})]}),(0,a.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"center",gap:"10px",marginTop:"16px",cursor:"pointer",color:"rgba(255, 255, 255, 0.55)",fontSize:"13px"},children:[(0,a.jsx)("input",{type:"checkbox",checked:i,onChange:e=>t(e.target.checked),style:{accentColor:"#ffffff",width:"14px",height:"14px",cursor:"pointer"}}),(0,a.jsx)("span",{children:"I agree to all terms and policies"})]})]})},"ScrollToTop",0,function(){return(0,a.jsx)("button",{onClick:function(){window.scrollTo({top:0,behavior:"smooth"})},"aria-label":"Scroll to top",style:{display:"none"}})},"SocialCircle",0,function({href:e,label:r,children:i}){let[t,m]=(0,n.useState)(!1);return(0,a.jsx)("a",{href:e||"#","aria-label":r,target:"_blank",rel:"noopener noreferrer",onMouseEnter:()=>m(!0),onMouseLeave:()=>m(!1),style:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:"38px",height:"38px",borderRadius:"50%",border:t?"1px solid #ffffff":"1px solid rgba(255, 255, 255, 0.25)",backgroundColor:t?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.03)",color:"#ffffff",textDecoration:"none",fontSize:"13px",fontWeight:600,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',transition:"all 0.25s ease",flexShrink:0},children:i})}])},69353,e=>{"use strict";var a=e.i(71645);e.s(["default",0,function({scripts:e}){let n=(0,a.useRef)(!1);return(0,a.useEffect)(()=>{n.current||(n.current=!0,a().catch(e=>{console.error(e)}));async function a(){let a=new Set(["TweenMax-min-js","aat.min-js"]),n=e.filter(e=>a.has(e.id)),r=e.filter(e=>!a.has(e.id)),i=r.findIndex(e=>"gemzie-js"===e.id);for(let e of(-1===i?r.push(...n):r.splice(i,0,...n),r))await function(e){if("speculationrules"===e.attribs.type)return Promise.resolve();let a=document.createElement("script");for(let[n,r]of Object.entries(e.attribs))"src"!==n&&"async"!==n&&"defer"!==n&&a.setAttribute(n,r);if(!e.src)return a.textContent=e.code,document.body.appendChild(a),Promise.resolve();a.async=!1;let n=new Promise((n,r)=>{a.addEventListener("load",n,{once:!0}),a.addEventListener("error",()=>{r(Error(`Failed to load legacy script: ${e.src}`))},{once:!0})});return a.src=e.src,document.body.appendChild(a),n}(e);window.dispatchEvent(new Event("load"))}},[e]),null}])},97073,e=>{"use strict";var a=e.i(43476),n=e.i(71645),r=e.i(74080);let i=[{id:"mi-home",label:"Home",href:"/",hasChildren:!1,children:null},{id:"mi-diamonds",label:"Diamonds",href:"/diamonds",hasChildren:!0,children:[{id:"mi-all-diamonds",label:"All Diamonds",href:"/diamonds"},{id:"mi-pink-diamonds",label:"Pink Diamonds",href:"/diamonds/pink"},{id:"mi-white-diamonds",label:"White Diamonds",href:"/diamonds/white"},{id:"mi-cyo",label:"Create Your Own",href:"/create-your-own"}]},{id:"mi-shop",label:"Shop",href:"/shop",hasChildren:!1,children:null},{id:"mi-wlg",label:"Why Lab Grown",href:"/why-lab-grown",hasChildren:!0,children:[{id:"mi-wlg-overview",label:"Why Lab Grown",href:"/why-lab-grown"},{id:"mi-wlg-guide",label:"Diamond Guide",href:"/diamond-guide"},{id:"mi-wlg-sourcing",label:"Sourcing",href:"/sourcing"}]},{id:"mi-about",label:"About Caritas",href:"/about-us",hasChildren:!1,children:null},{id:"mi-contact",label:"Contact",href:"/contact",hasChildren:!1,children:null}];function t(e,a){return e.href===a||(e.children?e.children.some(e=>e.href===a):!!("/"!==e.href&&"#"!==e.href&&a.startsWith(e.href)))}function m({items:e,parentId:n,currentPath:r}){return(0,a.jsx)("ul",{className:"mega-sub-menu",id:`mega-sub-menu-${n}`,children:e.map(e=>{let n=e.href===r;return(0,a.jsx)("li",{id:e.id,className:`mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page${n?" mega-current-menu-item mega-current_page_item":""}`,children:(0,a.jsx)("a",{className:"mega-menu-link",href:e.href,style:{color:"#ffffff",backgroundColor:n?"var(--primary-color, #BFA37C)":"transparent",fontWeight:n?700:500,borderRadius:"4px"},children:e.label})},e.id)})})}function o({currentPath:e}){return(0,a.jsx)("ul",{id:"mega-menu-primary",className:"mega-menu max-mega-menu mega-menu-horizontal mega-no-js","data-event":"hover_intent","data-effect":"fade_up","data-effect-speed":"200","data-effect-mobile":"disabled","data-effect-speed-mobile":"0","data-mobile-force-width":"false","data-second-click":"go","data-document-click":"collapse","data-vertical-behaviour":"standard","data-breakpoint":"1024","data-unbind":"true",children:i.map(n=>{let r=t(n,e),i="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom";return n.hasChildren&&(i+=" mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-dropdown"),r&&!n.hasChildren&&(i+=" mega-current-menu-item mega-current_page_item"),r&&n.hasChildren&&(i+=" mega-current-menu-ancestor mega-current-menu-parent"),(0,a.jsxs)("li",{id:n.id,className:i,children:[(0,a.jsxs)("a",{className:"mega-menu-link",href:n.href,style:{color:"#ffffff",backgroundColor:"transparent",fontWeight:r?700:500,display:"inline-flex",alignItems:"center",gap:"6px",position:"relative",zIndex:2,padding:"0 15px"},...n.hasChildren?{"aria-haspopup":"true","aria-expanded":"false","aria-controls":`mega-sub-menu-${n.id}`}:{},children:[(0,a.jsxs)("span",{style:{color:"#ffffff",position:"relative",zIndex:3},children:[n.label,"mi-about"===n.id&&(0,a.jsx)("span",{style:{display:"none"},children:"About Us"})]}),n.hasChildren&&(0,a.jsx)("span",{className:"mega-indicator","aria-hidden":"true",style:{color:"#ffffff",position:"relative",zIndex:3}})]}),n.hasChildren&&(0,a.jsx)(m,{items:n.children,parentId:n.id,currentPath:e})]},n.id)})})}function l({items:e,open:n,currentPath:r,onNavigate:i}){return(0,a.jsx)("ul",{style:{listStyle:"none",padding:"0 0 0 16px",margin:"4px 0 8px 16px",display:n?"block":"none",borderLeft:"2px solid var(--primary-color, #BFA37C)"},children:e.map(e=>{let n=e.href===r;return(0,a.jsx)("li",{children:(0,a.jsx)("a",{href:e.href,onClick:i,style:{display:"block",padding:"10px 16px",margin:"4px 0",backgroundColor:n?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"4px",textDecoration:"none",fontSize:"14px",fontWeight:n?700:500},children:e.label})},e.id)})})}function p({open:e,onClose:m,currentPath:o}){let[s,u]=(0,n.useState)(!1),[d,g]=(0,n.useState)(null);return((0,n.useEffect)(()=>{u(!0)},[]),(0,n.useEffect)(()=>{if(e){let e=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=e}}},[e]),s&&e)?(0,r.createPortal)((0,a.jsxs)("div",{id:"custom-mobile-drawer",role:"dialog","aria-modal":"true","aria-label":"Mobile Navigation",style:{position:"fixed",top:0,left:0,right:0,bottom:0,width:"100vw",height:"100vh",height:"100dvh",zIndex:0x7fffffff,backgroundColor:"#0C1315",overflowY:"auto",WebkitOverflowScrolling:"touch",paddingTop:"max(20px, env(safe-area-inset-top, 20px))",paddingBottom:"max(28px, env(safe-area-inset-bottom, 28px))",paddingLeft:"max(16px, env(safe-area-inset-left, 16px))",paddingRight:"max(16px, env(safe-area-inset-right, 16px))",boxSizing:"border-box",display:"flex",flexDirection:"column"},children:[(0,a.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px 18px",borderBottom:"1px solid rgba(255, 255, 255, 0.08)",flexShrink:0},children:[(0,a.jsx)("a",{href:"/",onClick:m,style:{display:"inline-flex",alignItems:"center"},children:(0,a.jsx)("img",{src:"/wp-content/uploads/2024/03/logo-white.png",alt:"Caritas Luxury",style:{height:"34px",width:"auto"}})}),(0,a.jsx)("button",{type:"button",onClick:m,"aria-label":"Close menu",style:{background:"rgba(255, 255, 255, 0.08)",border:"none",borderRadius:"50%",cursor:"pointer",color:"#ffffff",fontSize:"22px",lineHeight:1,width:"40px",height:"40px",display:"flex",alignItems:"center",justifyContent:"center"},children:"✕"})]}),(0,a.jsx)("ul",{style:{listStyle:"none",padding:"16px 0",margin:0,flex:"1 0 auto"},children:i.map(e=>{let n=t(e,o),r=d===e.id;return(0,a.jsxs)("li",{style:{borderBottom:"1px solid rgba(255, 255, 255, 0.06)"},children:[(0,a.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"6px 8px"},children:[(0,a.jsxs)("a",{href:e.href,onClick:a=>{e.hasChildren?(a.preventDefault(),g(r?null:e.id)):m()},style:{flex:1,display:"block",padding:"12px 14px",backgroundColor:n?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"6px",textDecoration:"none",fontSize:"17px",fontWeight:n?700:500,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)'},children:[e.label,"mi-about"===e.id&&(0,a.jsx)("span",{style:{display:"none"},children:"About Us"})]}),e.hasChildren&&(0,a.jsx)("button",{type:"button",onClick:()=>g(r?null:e.id),"aria-expanded":r,"aria-label":`Toggle ${e.label} sub-menu`,style:{background:"none",border:"none",color:"#ffffff",fontSize:"24px",padding:"10px 16px",cursor:"pointer",lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"},children:r?"−":"+"})]}),e.hasChildren&&(0,a.jsx)(l,{items:e.children,open:r,currentPath:o,onNavigate:m})]},e.id)})}),(0,a.jsx)("div",{style:{padding:"20px 8px 16px",marginTop:"auto",flexShrink:0},children:(0,a.jsx)("a",{href:"/contact",onClick:m,style:{display:"block",textAlign:"center",padding:"14px 20px",backgroundColor:"var(--primary-color, #BFA37C)",color:"#ffffff",borderRadius:"8px",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',fontSize:"16px",fontWeight:700,letterSpacing:"0.5px",textDecoration:"none"},children:"Get In Touch"})})]}),document.body):null}e.s(["default",0,function({currentPath:e="/"}){let[r,i]=(0,n.useState)(!1);return(0,n.useEffect)(()=>(document.body.style.overflow=r?"hidden":"",()=>{document.body.style.overflow=""}),[r]),(0,a.jsxs)("div",{id:"mega-menu-wrap-primary",className:"mega-menu-wrap",children:[(0,a.jsx)("style",{children:`
        /* Desktop dropdown styling and animation */
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children {
            position: relative;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children > ul.mega-sub-menu {
            display: none !important;
            position: absolute !important;
            top: 100% !important;
            left: 0 !important;
            min-width: 220px !important;
            background-color: #0C1315 !important;
            padding: 12px 8px !important;
            margin: 0 !important;
            border-radius: 6px !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.35) !important;
            z-index: 99999 !important;
            list-style: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:hover > ul.mega-sub-menu,
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:focus-within > ul.mega-sub-menu {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item {
            display: block !important;
            width: 100% !important;
            margin-bottom: 4px !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link {
            display: block !important;
            padding: 10px 18px !important;
            color: #ffffff !important;
            font-size: 14px !important;
            text-decoration: none !important;
            white-space: nowrap !important;
            border-radius: 4px !important;
            transition: all 0.2s ease !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover,
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-current-menu-item > a.mega-menu-link {
            background-color: var(--primary-color, #BFA37C) !important;
            color: #ffffff !important;
            font-weight: 700 !important;
          }
        }

        /* Top-level menu links – always white text so it is 100% visible inside the #BEA37C box */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-page-ancestor > a.mega-menu-link {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
          text-decoration: none !important;
          position: relative !important;
          z-index: 2 !important;
        }

        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link * {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
        }

        /* Ensure top-level a.mega-menu-link has transparent background so ONLY the 40px :before pill is visible */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link {
          background: transparent !important;
          background-color: transparent !important;
          border-radius: 0 !important;
        }

        /* The #BEA37C pill box is strictly rendered by :before so its size is 100% identical on hover and selected page */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:before {
          content: "" !important;
          position: absolute !important;
          top: 50% !important;
          transform: translateY(-50%) !important;
          height: 40px !important;
          border-radius: 6px !important;
          background: var(--primary-color, #BFA37C) !important;
          z-index: 1 !important;
          transition: width 0.25s ease, left 0.25s ease, opacity 0.25s ease !important;
        }

        /* Inactive items: box collapsed */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item:not(.mega-current-menu-item):not(.mega-current-menu-ancestor):not(.mega-current-page-ancestor) > a.mega-menu-link:not(:hover):before {
          width: 0 !important;
          left: 50% !important;
          opacity: 0 !important;
        }

        /* Hovered or selected/active: exact same 40px pill size */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link:before {
          width: 100% !important;
          left: 0 !important;
          height: 40px !important;
          opacity: 1 !important;
        }

        /* Mobile vs Desktop Display Rules */
        @media (max-width: 1023px) {
          /* Strictly hide desktop horizontal menu on mobile so it cannot conflict with mobile drawer */
          #mega-menu-wrap-primary #mega-menu-primary {
            display: none !important;
            visibility: hidden !important;
            pointer-events: none !important;
            position: absolute !important;
            left: -9999px !important;
            width: 0 !important;
            height: 0 !important;
            opacity: 0 !important;
            background: transparent !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: flex !important;
            cursor: pointer !important;
            background: transparent !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle:after,
          #mega-menu-wrap-primary .mega-menu-toggle.mega-menu-open:after {
            display: none !important;
            content: none !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::before,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::after {
            background-color: #ffffff !important;
          }
        }
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary {
            display: flex !important;
          }
        }
      `}),(0,a.jsxs)("div",{className:"mega-menu-toggle",onClickCapture:e=>{e.preventDefault(),e.stopPropagation(),i(!0)},children:[(0,a.jsx)("div",{className:"mega-toggle-blocks-left"}),(0,a.jsx)("div",{className:"mega-toggle-blocks-center"}),(0,a.jsx)("div",{className:"mega-toggle-blocks-right",children:(0,a.jsx)("div",{className:"mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-0",id:"mega-toggle-block-0",children:(0,a.jsx)("button",{className:"mega-toggle-animated mega-toggle-animated-slider",type:"button","aria-controls":"mega-menu-primary","aria-expanded":r,"aria-haspopup":"true","aria-label":"Toggle Menu",onClick:e=>{e.preventDefault(),e.stopPropagation(),i(!0)},children:(0,a.jsx)("span",{className:"mega-toggle-animated-box",children:(0,a.jsx)("span",{className:"mega-toggle-animated-inner"})})})})})]}),(0,a.jsx)(o,{currentPath:e}),(0,a.jsx)(p,{open:r,onClose:()=>i(!1),currentPath:e})]})}])}]);