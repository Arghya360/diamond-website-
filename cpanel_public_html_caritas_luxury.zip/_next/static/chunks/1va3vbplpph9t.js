(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,39287,e=>{"use strict";var t=e.i(43476),a=e.i(71645);e.s(["CrystoSubscribeForm",0,function(){let[r,n]=(0,a.useState)(""),[i,o]=(0,a.useState)(!1);async function l(t){if(t.preventDefault(),r){try{let{addDoc:t,collection:a,serverTimestamp:n}=await e.A(27510),{db:i}=await e.A(43414);await t(a(i,"customers"),{email:r.trim(),name:r.split("@")[0],type:"subscriber",totalOrders:0,totalSpent:0,createdAt:n()})}catch(e){}alert("Thank you for subscribing to Caritas Luxury!"),n("")}}return(0,t.jsxs)("form",{onSubmit:l,style:{width:"100%",maxWidth:"680px",margin:"0 auto"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",borderBottom:"1px solid rgba(255, 255, 255, 0.28)",paddingBottom:"8px",gap:"16px"},children:[(0,t.jsx)("input",{type:"email",value:r,onChange:e=>n(e.target.value),placeholder:"Enter your email address",required:!0,"aria-label":"Enter your email address",style:{flex:1,background:"transparent",border:"none",outline:"none",color:"#ffffff",fontSize:"15px",fontFamily:"inherit",padding:"8px 0"}}),(0,t.jsx)("button",{type:"submit",style:{background:"none",border:"none",color:"#ffffff",fontSize:"13px",fontWeight:700,letterSpacing:"1.2px",textTransform:"uppercase",textDecoration:"underline",textUnderlineOffset:"6px",cursor:"pointer",padding:"8px 0",whiteSpace:"nowrap",fontFamily:"inherit"},children:"SUBSCRIBE NOW"})]}),(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"center",gap:"10px",marginTop:"16px",cursor:"pointer",color:"rgba(255, 255, 255, 0.55)",fontSize:"13px"},children:[(0,t.jsx)("input",{type:"checkbox",checked:i,onChange:e=>o(e.target.checked),style:{accentColor:"#ffffff",width:"14px",height:"14px",cursor:"pointer"}}),(0,t.jsx)("span",{children:"I agree to all terms and policies"})]})]})},"ScrollToTop",0,function(){return(0,t.jsx)("button",{onClick:function(){window.scrollTo({top:0,behavior:"smooth"})},"aria-label":"Scroll to top",style:{display:"none"}})},"SocialCircle",0,function({href:e,label:r,children:n}){let[i,o]=(0,a.useState)(!1);return(0,t.jsx)("a",{href:e||"#","aria-label":r,target:"_blank",rel:"noopener noreferrer",onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),style:{display:"inline-flex",alignItems:"center",justifyContent:"center",width:"38px",height:"38px",borderRadius:"50%",border:i?"1px solid #ffffff":"1px solid rgba(255, 255, 255, 0.25)",backgroundColor:i?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.03)",color:"#ffffff",textDecoration:"none",fontSize:"13px",fontWeight:600,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',transition:"all 0.25s ease",flexShrink:0},children:n})}])},69353,e=>{"use strict";var t=e.i(71645);e.s(["default",0,function({scripts:e}){let a=(0,t.useRef)(!1);return(0,t.useEffect)(()=>{a.current||(a.current=!0,t().catch(e=>{console.error(e)}));async function t(){let t=new Set(["TweenMax-min-js","aat.min-js"]),a=e.filter(e=>t.has(e.id)),r=e.filter(e=>!t.has(e.id)),n=r.findIndex(e=>"gemzie-js"===e.id);for(let e of(-1===n?r.push(...a):r.splice(n,0,...a),r))await function(e){if("speculationrules"===e.attribs.type)return Promise.resolve();let t=document.createElement("script");for(let[a,r]of Object.entries(e.attribs))"src"!==a&&"async"!==a&&"defer"!==a&&t.setAttribute(a,r);if(!e.src)return t.textContent=e.code,document.body.appendChild(t),Promise.resolve();t.async=!1;let a=new Promise((a,r)=>{t.addEventListener("load",a,{once:!0}),t.addEventListener("error",()=>{r(Error(`Failed to load legacy script: ${e.src}`))},{once:!0})});return t.src=e.src,document.body.appendChild(t),a}(e);window.dispatchEvent(new Event("load")),setTimeout(()=>{try{window.dispatchEvent(new Event("resize")),window.dispatchEvent(new Event("scroll")),window.jQuery&&(window.jQuery(window).trigger("resize").trigger("scroll"),window.jQuery(".elementor-invisible").each(function(){let e=window.jQuery(this),t=e.data("settings"),a="object"==typeof t&&t?._animation||"fadeInUp";e.removeClass("elementor-invisible").addClass("animated "+a)}))}catch(e){console.warn("Animation trigger fallback:",e)}},500)}},[e]),null}])},97073,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(74080);let n=[{id:"mi-home",label:"Home",href:"/",hasChildren:!1,children:null},{id:"mi-diamonds",label:"Diamonds",href:"/diamonds",hasChildren:!0,children:[{id:"mi-all-diamonds",label:"All Diamonds",href:"/diamonds"},{id:"mi-pink-diamonds",label:"Pink Diamonds",href:"/diamonds/pink"},{id:"mi-white-diamonds",label:"White Diamonds",href:"/diamonds/white"},{id:"mi-cyo",label:"Create Your Own",href:"/create-your-own"}]},{id:"mi-shop",label:"Shop",href:"/shop",hasChildren:!1,children:null},{id:"mi-wlg",label:"Why Lab Grown",href:"/why-lab-grown",hasChildren:!0,children:[{id:"mi-wlg-overview",label:"Why Lab Grown",href:"/why-lab-grown"},{id:"mi-wlg-guide",label:"Diamond Guide",href:"/diamond-guide"},{id:"mi-wlg-sourcing",label:"Sourcing",href:"/sourcing"}]},{id:"mi-about",label:"About Caritas",href:"/about-us",hasChildren:!1,children:null},{id:"mi-contact",label:"Contact",href:"/contact",hasChildren:!1,children:null}];function i(e,t){return e.href===t||(e.children?e.children.some(e=>e.href===t):!!("/"!==e.href&&"#"!==e.href&&t.startsWith(e.href)))}function o({items:e,parentId:a,currentPath:r}){return(0,t.jsx)("ul",{className:"mega-sub-menu",id:`mega-sub-menu-${a}`,children:e.map(e=>{let a=e.href===r;return(0,t.jsx)("li",{id:e.id,className:`mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page${a?" mega-current-menu-item mega-current_page_item":""}`,children:(0,t.jsx)("a",{className:"mega-menu-link",href:e.href,style:{color:"#ffffff",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",fontWeight:a?700:500,borderRadius:"4px"},children:e.label})},e.id)})})}function l({currentPath:e,menu:a=n}){return(0,t.jsx)("ul",{id:"mega-menu-primary",className:"mega-menu max-mega-menu mega-menu-horizontal mega-no-js","data-event":"hover_intent","data-effect":"fade_up","data-effect-speed":"200","data-effect-mobile":"disabled","data-effect-speed-mobile":"0","data-mobile-force-width":"false","data-second-click":"go","data-document-click":"collapse","data-vertical-behaviour":"standard","data-breakpoint":"1024","data-unbind":"true",children:a.map(a=>{let r=i(a,e),n="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom";return a.hasChildren&&(n+=" mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-dropdown"),r&&!a.hasChildren&&(n+=" mega-current-menu-item mega-current_page_item"),r&&a.hasChildren&&(n+=" mega-current-menu-ancestor mega-current-menu-parent"),(0,t.jsxs)("li",{id:a.id,className:n,children:[(0,t.jsxs)("a",{className:"mega-menu-link",href:a.href,style:{color:"#ffffff",backgroundColor:"transparent",fontWeight:r?700:500,display:"inline-flex",alignItems:"center",gap:"6px",position:"relative",zIndex:2,padding:"0 15px"},...a.hasChildren?{"aria-haspopup":"true","aria-expanded":"false","aria-controls":`mega-sub-menu-${a.id}`}:{},children:[(0,t.jsxs)("span",{style:{color:"#ffffff",position:"relative",zIndex:3},children:[a.label,"mi-about"===a.id&&(0,t.jsx)("span",{style:{display:"none"},children:"About Us"})]}),a.hasChildren&&(0,t.jsx)("span",{className:"mega-indicator","aria-hidden":"true",style:{color:"#ffffff",position:"relative",zIndex:3}})]}),a.hasChildren&&(0,t.jsx)(o,{items:a.children,parentId:a.id,currentPath:e})]},a.id)})})}function m({items:e,open:a,currentPath:r,onNavigate:n}){return(0,t.jsx)("ul",{style:{listStyle:"none",padding:"0 0 0 16px",margin:"4px 0 8px 16px",display:a?"block":"none",borderLeft:"2px solid var(--primary-color, #BFA37C)"},children:e.map(e=>{let a=e.href===r;return(0,t.jsx)("li",{children:(0,t.jsx)("a",{href:e.href,onClick:n,style:{display:"block",padding:"10px 16px",margin:"4px 0",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"4px",textDecoration:"none",fontSize:"14px",fontWeight:a?700:500},children:e.label})},e.id)})})}function s({open:e,onClose:o,currentPath:l,menu:u=n}){let[d,p]=(0,a.useState)(!1),[c,g]=(0,a.useState)(null);return((0,a.useEffect)(()=>{p(!0)},[]),(0,a.useEffect)(()=>{if(e){let e=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=e}}},[e]),d&&e)?(0,r.createPortal)((0,t.jsxs)("div",{id:"custom-mobile-drawer",role:"dialog","aria-modal":"true","aria-label":"Mobile Navigation",style:{position:"fixed",top:0,left:0,right:0,bottom:0,width:"100vw",height:"100vh",height:"100dvh",zIndex:0x7fffffff,backgroundColor:"#0C1315",overflowY:"auto",WebkitOverflowScrolling:"touch",paddingTop:"max(20px, env(safe-area-inset-top, 20px))",paddingBottom:"max(28px, env(safe-area-inset-bottom, 28px))",paddingLeft:"max(16px, env(safe-area-inset-left, 16px))",paddingRight:"max(16px, env(safe-area-inset-right, 16px))",boxSizing:"border-box",display:"flex",flexDirection:"column"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px 18px",borderBottom:"1px solid rgba(255, 255, 255, 0.08)",flexShrink:0},children:[(0,t.jsx)("a",{href:"/",onClick:o,style:{display:"inline-flex",alignItems:"center"},children:(0,t.jsx)("img",{src:"/wp-content/uploads/2024/03/logo-white.png",alt:"Caritas Luxury",style:{height:"34px",width:"auto"}})}),(0,t.jsx)("button",{type:"button",onClick:o,"aria-label":"Close menu",style:{background:"rgba(255, 255, 255, 0.08)",border:"none",borderRadius:"50%",cursor:"pointer",color:"#ffffff",fontSize:"22px",lineHeight:1,width:"40px",height:"40px",display:"flex",alignItems:"center",justifyContent:"center"},children:"✕"})]}),(0,t.jsx)("ul",{style:{listStyle:"none",padding:"16px 0",margin:0,flex:"1 0 auto"},children:u.map(e=>{let a=i(e,l),r=c===e.id;return(0,t.jsxs)("li",{style:{borderBottom:"1px solid rgba(255, 255, 255, 0.06)"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"6px 8px"},children:[(0,t.jsxs)("a",{href:e.href,onClick:t=>{e.hasChildren?(t.preventDefault(),g(r?null:e.id)):o()},style:{flex:1,display:"block",padding:"12px 14px",backgroundColor:a?"var(--primary-color, #BFA37C)":"transparent",color:"#ffffff",borderRadius:"6px",textDecoration:"none",fontSize:"17px",fontWeight:a?700:500,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)'},children:[e.label,"mi-about"===e.id&&(0,t.jsx)("span",{style:{display:"none"},children:"About Us"})]}),e.hasChildren&&(0,t.jsx)("button",{type:"button",onClick:()=>g(r?null:e.id),"aria-expanded":r,"aria-label":`Toggle ${e.label} sub-menu`,style:{background:"none",border:"none",color:"#ffffff",fontSize:"24px",padding:"10px 16px",cursor:"pointer",lineHeight:1,display:"flex",alignItems:"center",justifyContent:"center"},children:r?"−":"+"})]}),e.hasChildren&&(0,t.jsx)(m,{items:e.children,open:r,currentPath:l,onNavigate:o})]},e.id)})}),(0,t.jsx)("div",{style:{padding:"20px 8px 16px",marginTop:"auto",flexShrink:0},children:(0,t.jsx)("a",{href:"/contact",onClick:o,style:{display:"block",textAlign:"center",padding:"14px 20px",backgroundColor:"var(--primary-color, #BFA37C)",color:"#ffffff",borderRadius:"8px",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',fontSize:"16px",fontWeight:700,letterSpacing:"0.5px",textDecoration:"none"},children:"Get In Touch"})})]}),document.body):null}e.s(["default",0,function({currentPath:r="/"}){let[i,o]=(0,a.useState)(!1),[m,u]=(0,a.useState)(n);return(0,a.useEffect)(()=>{e.A(2187).then(({getNavigation:e})=>{e().then(e=>{e&&e.length>0&&u(e.filter(e=>!1!==e.active))}).catch(()=>{})}).catch(()=>{})},[]),(0,a.useEffect)(()=>(document.body.style.overflow=i?"hidden":"",()=>{document.body.style.overflow=""}),[i]),(0,a.useEffect)(()=>{let e=e=>{e.target.closest(".menu-toggle, .pt-toggle-btn")&&(e.preventDefault(),e.stopPropagation(),o(!0))};return document.addEventListener("click",e),()=>document.removeEventListener("click",e)},[]),(0,t.jsxs)("div",{id:"mega-menu-wrap-primary",className:"mega-menu-wrap",children:[(0,t.jsx)("style",{children:`
        /* Desktop dropdown styling and animation */
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children {
            position: relative;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children > ul.mega-sub-menu {
            display: none !important;
            position: absolute !important;
            top: 100% !important;
            left: 0 !important;
            min-width: 220px !important;
            background-color: #0C1315 !important;
            padding: 12px 8px !important;
            margin: 0 !important;
            border-radius: 6px !important;
            box-shadow: 0 10px 30px rgba(0,0,0,0.35) !important;
            z-index: 99999 !important;
            list-style: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:hover > ul.mega-sub-menu,
          #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item-has-children:focus-within > ul.mega-sub-menu {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item {
            display: block !important;
            width: 100% !important;
            margin-bottom: 4px !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link {
            display: block !important;
            padding: 10px 18px !important;
            color: #ffffff !important;
            font-size: 14px !important;
            text-decoration: none !important;
            white-space: nowrap !important;
            border-radius: 4px !important;
            transition: all 0.2s ease !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-menu-item > a.mega-menu-link:hover,
          #mega-menu-wrap-primary #mega-menu-primary ul.mega-sub-menu > li.mega-current-menu-item > a.mega-menu-link {
            background-color: var(--primary-color, #BFA37C) !important;
            color: #ffffff !important;
            font-weight: 700 !important;
          }
        }

        /* Top-level menu links – always white text so it is 100% visible inside the #BEA37C box */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-page-ancestor > a.mega-menu-link {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
          text-decoration: none !important;
          position: relative !important;
          z-index: 2 !important;
        }

        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-item > a.mega-menu-link *,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item.mega-current-menu-ancestor > a.mega-menu-link * {
          color: #ffffff !important;
          opacity: 1 !important;
          visibility: visible !important;
        }

        /* Ensure top-level a.mega-menu-link has transparent background so ONLY the 40px :before pill is visible */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:focus,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:active,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link {
          background: transparent !important;
          background-color: transparent !important;
          border-radius: 0 !important;
        }

        /* The #BEA37C pill box is strictly rendered by :before so its size is 100% identical on hover and selected page */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:before {
          content: "" !important;
          position: absolute !important;
          top: 50% !important;
          transform: translateY(-50%) !important;
          height: 40px !important;
          border-radius: 6px !important;
          background: var(--primary-color, #BFA37C) !important;
          z-index: 1 !important;
          transition: width 0.25s ease, left 0.25s ease, opacity 0.25s ease !important;
        }

        /* Inactive items: box collapsed */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item:not(.mega-current-menu-item):not(.mega-current-menu-ancestor):not(.mega-current-page-ancestor) > a.mega-menu-link:not(:hover):before {
          width: 0 !important;
          left: 50% !important;
          opacity: 0 !important;
        }

        /* Hovered or selected/active: exact same 40px pill size */
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-menu-item > a.mega-menu-link:hover:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-item > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-menu-ancestor > a.mega-menu-link:before,
        #mega-menu-wrap-primary #mega-menu-primary > li.mega-current-page-ancestor > a.mega-menu-link:before {
          width: 100% !important;
          left: 0 !important;
          height: 40px !important;
          opacity: 1 !important;
        }

        /* Mobile vs Desktop Display Rules */
        @media (max-width: 1023px) {
          /* Strictly hide desktop horizontal menu on mobile so it cannot conflict with mobile drawer */
          #mega-menu-wrap-primary #mega-menu-primary {
            display: none !important;
            visibility: hidden !important;
            pointer-events: none !important;
            position: absolute !important;
            left: -9999px !important;
            width: 0 !important;
            height: 0 !important;
            opacity: 0 !important;
            background: transparent !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            background: transparent !important;
            min-width: 44px !important;
            min-height: 44px !important;
            padding: 8px !important;
            z-index: 100 !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle:after,
          #mega-menu-wrap-primary .mega-menu-toggle.mega-menu-open:after {
            display: none !important;
            content: none !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-box {
            width: 30px !important;
            height: 22px !important;
            display: inline-block !important;
            position: relative !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::before,
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::after {
            display: block !important;
            width: 30px !important;
            height: 3px !important;
            background-color: #ffffff !important;
            border-radius: 2px !important;
            position: absolute !important;
            left: 0 !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner {
            top: 50% !important;
            transform: translateY(-50%) !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::before {
            content: "" !important;
            top: -8px !important;
          }
          #mega-menu-wrap-primary .mega-menu-toggle .mega-toggle-animated-inner::after {
            content: "" !important;
            top: 8px !important;
          }
        }
        @media (min-width: 1024px) {
          #mega-menu-wrap-primary .mega-menu-toggle {
            display: none !important;
          }
          #mega-menu-wrap-primary #mega-menu-primary {
            display: flex !important;
          }
        }
      `}),(0,t.jsxs)("div",{className:"mega-menu-toggle",onClickCapture:e=>{e.preventDefault(),e.stopPropagation(),o(!0)},children:[(0,t.jsx)("div",{className:"mega-toggle-blocks-left"}),(0,t.jsx)("div",{className:"mega-toggle-blocks-center"}),(0,t.jsx)("div",{className:"mega-toggle-blocks-right",children:(0,t.jsx)("div",{className:"mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-0",id:"mega-toggle-block-0",children:(0,t.jsx)("button",{className:"mega-toggle-animated mega-toggle-animated-slider",type:"button","aria-controls":"mega-menu-primary","aria-expanded":i,"aria-haspopup":"true","aria-label":"Toggle Menu",onClick:e=>{e.preventDefault(),e.stopPropagation(),o(!0)},children:(0,t.jsx)("span",{className:"mega-toggle-animated-box",children:(0,t.jsx)("span",{className:"mega-toggle-animated-inner"})})})})})]}),(0,t.jsx)(l,{currentPath:r,menu:m}),(0,t.jsx)(s,{open:i,onClose:()=>o(!1),currentPath:r,menu:m})]})}])},5500,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"Image",{enumerable:!0,get:function(){return x}});let r=e.r(55682),n=e.r(90809),i=e.r(43476),o=n._(e.r(71645)),l=r._(e.r(74080)),m=r._(e.r(25633)),s=e.r(8927),u=e.r(65856),d=e.r(49381),p=r._(e.r(1948)),c=e.r(18581);function g(e,t,a,r,n,i,o){let l=e?.src;e&&e["data-loaded-src"]!==l&&(e["data-loaded-src"]=l,("decode"in e?e.decode():Promise.resolve()).catch(()=>{}).then(()=>{if(e.parentElement&&e.isConnected){if("empty"!==t&&n(!0),a?.current){let t=new Event("load");Object.defineProperty(t,"target",{writable:!1,value:e});let r=!1,n=!1;a.current({...t,nativeEvent:t,currentTarget:e,target:e,isDefaultPrevented:()=>r,isPropagationStopped:()=>n,persist:()=>{},preventDefault:()=>{r=!0,t.preventDefault()},stopPropagation:()=>{n=!0,t.stopPropagation()}})}r?.current&&r.current(e)}}))}function f(e){return o.use?{fetchPriority:e}:{fetchpriority:e}}"u"<typeof window&&(globalThis.__NEXT_IMAGE_IMPORTED=!0);let h="u"<typeof window?o.useEffect:o.useLayoutEffect,y=(0,o.forwardRef)(({src:e,srcSet:t,sizes:a,height:r,width:n,decoding:l,className:m,style:s,fetchPriority:u,placeholder:d,loading:p,unoptimized:y,fill:b,onLoadRef:x,onLoadingCompleteRef:w,setBlurComplete:v,setShowAltText:j,sizesInput:k,onLoad:C,onError:S,..._},P)=>{let E=(0,o.useRef)(!1),z=(0,o.useRef)(null);h(()=>{let{current:e}=E,{current:t}=z;e||null===t||(S&&(t.src=t.src),t.complete&&g(t,d,x,w,v,y,k),E.current=!0)},[e,d,x,w,S,y,k]);let I=(0,c.useMergedRef)(P,z);return(0,i.jsx)("img",{..._,...f(u),loading:p,width:n,height:r,decoding:l,"data-nimg":b?"fill":"1",className:m,style:s,sizes:a,srcSet:t,src:e,ref:I,onLoad:e=>{g(e.currentTarget,d,x,w,v,y,k)},onError:e=>{j(!0),"empty"!==d&&v(!0),S&&S(e)}})});function b({isAppRouter:e,imgAttributes:t}){let a={as:"image",imageSrcSet:t.srcSet,imageSizes:t.sizes,crossOrigin:t.crossOrigin,referrerPolicy:t.referrerPolicy,...f(t.fetchPriority)};return e&&l.default.preload?(l.default.preload(t.src,a),null):(0,i.jsx)(m.default,{children:(0,i.jsx)("link",{rel:"preload",href:t.srcSet?void 0:t.src,...a},"__nimg-"+t.src+t.srcSet+t.sizes)})}let x=(0,o.forwardRef)((e,t)=>{let a=(0,o.useContext)(u.RouterContext),r=(0,d.useImageConfig)(),{onLoad:n,onLoadingComplete:l}=e,m=(0,o.useRef)(n);(0,o.useEffect)(()=>{m.current=n},[n]);let c=(0,o.useRef)(l);(0,o.useEffect)(()=>{c.current=l},[l]);let[g,f]=(0,o.useState)(!1),[h,x]=(0,o.useState)(!1),{props:w,meta:v}=(0,s.getImgProps)(e,{defaultLoader:p.default,imgConf:r,blurComplete:g,showAltText:h});return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(y,{...w,unoptimized:v.unoptimized,placeholder:v.placeholder,fill:v.fill,onLoadRef:m,onLoadingCompleteRef:c,setBlurComplete:f,setShowAltText:x,sizesInput:e.sizes,ref:t}),v.preload?(0,i.jsx)(b,{isAppRouter:!a,imgAttributes:w}):null]})});("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)},25164,e=>{"use strict";var t=e.i(5500);e.s(["default",()=>t.Image])},49381,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"useImageConfig",{enumerable:!0,get:function(){return l}});let r=e.r(71645),n=e.r(87690),i=e.r(18556),o={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],qualities:[75],path:"/_next/image/",loader:"default",dangerouslyAllowSVG:!1,unoptimized:!0};function l(){let e=(0,r.useContext)(i.ImageConfigContext);return(0,n.prepareImageConfig)(o,e)}("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)},70965,(e,t,a)=>{"use strict";function r(e,t){let a=e||75;return t?.qualities?.length?t.qualities.reduce((e,t)=>Math.abs(t-a)<Math.abs(e-a)?t:e,t.qualities[0]):a}Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"findClosestQuality",{enumerable:!0,get:function(){return r}})},8927,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"getImgProps",{enumerable:!0,get:function(){return m}});let r=e.r(43369),n=e.r(88143),i=["-moz-initial","fill","none","scale-down",void 0];function o(e){return void 0!==e.default}function l(e){return void 0===e?e:"number"==typeof e?Number.isFinite(e)?e:0/0:"string"==typeof e&&/^[0-9]+$/.test(e)?parseInt(e,10):0/0}function m({src:e,sizes:t,unoptimized:a=!1,priority:s=!1,preload:u=!1,loading:d,className:p,quality:c,width:g,height:f,fill:h=!1,style:y,overrideSrc:b,onLoad:x,onLoadingComplete:w,placeholder:v="empty",blurDataURL:j,fetchPriority:k,decoding:C="async",layout:S,objectFit:_,objectPosition:P,lazyBoundary:E,lazyRoot:z,...I},O){var R;let A,M,{imgConf:D,showAltText:T,blurComplete:$,defaultLoader:B}=O;if(void 0===B)throw Error("images.loaderFile detected but the file is missing default export.\nRead more: https://nextjs.org/docs/messages/invalid-images-config");let W=I.loader||B;delete I.loader,delete I.srcSet;let L="__next_img_default"in W;if(L){if("custom"===D.loader)throw Error(`Image with src "${e}" is missing "loader" prop.
Read more: https://nextjs.org/docs/messages/next-image-missing-loader`)}else{let e=W;W=t=>{let{config:a,...r}=t;return e(r)}}if(S){"fill"===S&&(h=!0);let e={intrinsic:{maxWidth:"100%",height:"auto"},responsive:{width:"100%",height:"auto"}}[S];e&&(y={...y,...e});let a={responsive:"100vw",fill:"100vw"}[S];a&&!t&&(t=a)}let F="",N=l(g),U=l(f);if((R=e)&&"object"==typeof R&&(o(R)||void 0!==R.src)){let t=o(e)?e.default:e;if(!t.src)throw Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(t)}`);if(!t.height||!t.width)throw Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(t)}`);if(A=t.blurWidth,M=t.blurHeight,j=j||t.blurDataURL,F=t.src,!h)if(N||U){if(N&&!U){let e=N/t.width;U=Math.round(t.height*e)}else if(!N&&U){let e=U/t.height;N=Math.round(t.width*e)}}else N=t.width,U=t.height}let G=!s&&!u&&("lazy"===d||void 0===d);(!(e="string"==typeof e?e:F)||e.startsWith("data:")||e.startsWith("blob:"))&&(a=!0,G=!1),D.unoptimized&&(a=!0),L&&!D.dangerouslyAllowSVG&&e.split("?",1)[0].endsWith(".svg")&&(a=!0);let q=l(c),H=Object.assign(h?{position:"absolute",height:"100%",width:"100%",left:0,top:0,right:0,bottom:0,objectFit:_,objectPosition:P}:{},T?{}:{color:"transparent"},y),Y=$||"empty"===v?null:"blur"===v?`url("data:image/svg+xml;charset=utf-8,${(0,n.getImageBlurSvg)({widthInt:N,heightInt:U,blurWidth:A,blurHeight:M,blurDataURL:j||"",objectFit:H.objectFit})}")`:`url("${v}")`,Q=i.includes(H.objectFit)?"fill"===H.objectFit?"100% 100%":"cover":H.objectFit,V=Y?{backgroundSize:Q,backgroundPosition:H.objectPosition||"50% 50%",backgroundRepeat:"no-repeat",backgroundImage:Y}:{},J=function({config:e,src:t,unoptimized:a,width:n,quality:i,sizes:o,loader:l}){if(a){if(t.startsWith("/")&&!t.startsWith("//")){let e=(0,r.getDeploymentId)();if(t.includes("/_next/static/immutable")&&!(0,r.getAssetToken)())e=void 0;else if(e){let a=t.indexOf("?");if(-1!==a){let r=new URLSearchParams(t.slice(a+1));r.get("dpl")||(r.append("dpl",e),t=t.slice(0,a)+"?"+r.toString())}else t+=`?dpl=${e}`}}return{src:t,srcSet:void 0,sizes:void 0}}let{widths:m,kind:s}=function({deviceSizes:e,allSizes:t},a,r){if(r){let a=/(^|\s)(1?\d?\d)vw/g,n=[];for(let e;e=a.exec(r);)n.push(parseInt(e[2]));if(n.length){let a=.01*Math.min(...n);return{widths:t.filter(t=>t>=e[0]*a),kind:"w"}}return{widths:t,kind:"w"}}return"number"!=typeof a?{widths:e,kind:"w"}:{widths:[...new Set([a,2*a].map(e=>t.find(t=>t>=e)||t[t.length-1]))],kind:"x"}}(e,n,o),u=m.length-1;return{sizes:o||"w"!==s?o:"100vw",srcSet:m.map((a,r)=>`${l({config:e,src:t,quality:i,width:a})} ${"w"===s?a:r+1}${s}`).join(", "),src:l({config:e,src:t,quality:i,width:m[u]})}}({config:D,src:e,unoptimized:a,width:N,quality:q,sizes:t,loader:W}),K=G?"lazy":d;return{props:{...I,loading:K,fetchPriority:k,width:N,height:U,decoding:C,className:p,style:{...H,...V},sizes:J.sizes,srcSet:J.srcSet,src:b||J.src},meta:{unoptimized:a,preload:u||s,placeholder:v,fill:h}}}},25633,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0});var r={default:function(){return f},defaultHead:function(){return d}};for(var n in r)Object.defineProperty(a,n,{enumerable:!0,get:r[n]});let i=e.r(55682),o=e.r(90809),l=e.r(43476),m=o._(e.r(71645)),s=i._(e.r(98879)),u=e.r(42732);function d(){return[(0,l.jsx)("meta",{charSet:"utf-8"},"charset"),(0,l.jsx)("meta",{name:"viewport",content:"width=device-width"},"viewport")]}function p(e,t){return"string"==typeof t||"number"==typeof t?e:t.type===m.default.Fragment?e.concat(m.default.Children.toArray(t.props.children).reduce((e,t)=>"string"==typeof t||"number"==typeof t?e:e.concat(t),[])):e.concat(t)}let c=["name","httpEquiv","charSet","itemProp"];function g(e){let t,a,r,n;return e.reduce(p,[]).reverse().concat(d().reverse()).filter((t=new Set,a=new Set,r=new Set,n={},e=>{let i=!0,o=!1;if(e.key&&"number"!=typeof e.key&&e.key.indexOf("$")>0){o=!0;let a=e.key.slice(e.key.indexOf("$")+1);t.has(a)?i=!1:t.add(a)}switch(e.type){case"title":case"base":a.has(e.type)?i=!1:a.add(e.type);break;case"meta":for(let t=0,a=c.length;t<a;t++){let a=c[t];if(e.props.hasOwnProperty(a))if("charSet"===a)r.has(a)?i=!1:r.add(a);else{let t=e.props[a],r=n[a]||new Set;("name"!==a||!o)&&r.has(t)?i=!1:(r.add(t),n[a]=r)}}}return i})).reverse().map((e,t)=>{let a=e.key||t;return m.default.cloneElement(e,{key:a})})}let f=function({children:e}){let t=(0,m.useContext)(u.HeadManagerContext);return(0,l.jsx)(s.default,{reduceComponentsToState:g,headManager:t,children:e})};("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)},88143,(e,t,a)=>{"use strict";function r({widthInt:e,heightInt:t,blurWidth:a,blurHeight:n,blurDataURL:i,objectFit:o}){let l=a?40*a:e,m=n?40*n:t,s=l&&m?`viewBox='0 0 ${l} ${m}'`:"";return`%3Csvg xmlns='http://www.w3.org/2000/svg' ${s}%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3CfeColorMatrix values='1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 100 -1' result='s'/%3E%3CfeFlood x='0' y='0' width='100%25' height='100%25'/%3E%3CfeComposite operator='out' in='s'/%3E%3CfeComposite in2='SourceGraphic'/%3E%3CfeGaussianBlur stdDeviation='20'/%3E%3C/filter%3E%3Cimage width='100%25' height='100%25' x='0' y='0' preserveAspectRatio='${s?"none":"contain"===o?"xMidYMid":"cover"===o?"xMidYMid slice":"none"}' style='filter: url(%23b);' href='${i}'/%3E%3C/svg%3E`}Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"getImageBlurSvg",{enumerable:!0,get:function(){return r}})},18556,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"ImageConfigContext",{enumerable:!0,get:function(){return i}});let r=e.r(55682)._(e.r(71645)),n=e.r(87690),i=r.default.createContext(n.imageConfigDefault)},87690,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var r={VALID_LOADERS:function(){return i},imageConfigDefault:function(){return s},prepareImageConfig:function(){return m}};for(var n in r)Object.defineProperty(a,n,{enumerable:!0,get:r[n]});let i=["default","imgix","cloudinary","akamai","custom"],o={},l=new WeakMap;function m(e,t){let a=e??o,r=t??o,n=l.get(a);if(n){let e=n.get(r);if(e)return e}let i=e||t||s,m=[...i.deviceSizes].sort((e,t)=>e-t),u=[...i.imageSizes],d={deviceSizes:m,imageSizes:u,allSizes:[...m,...u].sort((e,t)=>e-t),qualities:void 0===i.qualities?void 0:[...i.qualities].sort((e,t)=>e-t),path:i.path,loader:i.loader,dangerouslyAllowSVG:i.dangerouslyAllowSVG,unoptimized:i.unoptimized,domains:i.domains,remotePatterns:i.remotePatterns,localPatterns:"u"<typeof window&&void 0!==t?t.localPatterns:i.localPatterns,output:i.output};return n||(n=new WeakMap,l.set(a,n)),n.set(r,d),d}let s={deviceSizes:[640,750,828,1080,1200,1920,2048,3840],imageSizes:[32,48,64,96,128,256,384],path:"/_next/image",loader:"default",loaderFile:"",domains:[],disableStaticImages:!1,minimumCacheTTL:14400,formats:["image/webp"],maximumDiskCacheSize:void 0,maximumRedirects:3,maximumResponseBody:5e7,dangerouslyAllowLocalIP:!1,dangerouslyAllowSVG:!1,contentSecurityPolicy:"script-src 'none'; frame-src 'none'; sandbox;",contentDispositionType:"attachment",localPatterns:void 0,remotePatterns:[],qualities:[75],unoptimized:!1,customCacheHandler:!1}},1948,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"default",{enumerable:!0,get:function(){return o}});let r=e.r(70965),n=e.r(43369);function i({config:e,src:t,width:a,quality:o}){let l=(0,n.getDeploymentId)();if(t.startsWith("/")&&!t.startsWith("//"))if(t.includes("/_next/static/immutable")&&!(0,n.getAssetToken)())l=void 0;else{let e=t.indexOf("?");if(-1!==e){let a=new URLSearchParams(t.slice(e+1)),r=a.get("dpl");if(r){l=r,a.delete("dpl");let n=a.toString();t=t.slice(0,e)+(n?"?"+n:"")}}}if(t.startsWith("/")&&t.includes("?")&&e.localPatterns?.length===1&&"**"===e.localPatterns[0].pathname&&""===e.localPatterns[0].search)throw Error(`Image with src "${t}" is using a query string which is not configured in images.localPatterns.
Read more: https://nextjs.org/docs/messages/next-image-unconfigured-localpatterns`);let m=(0,r.findClosestQuality)(o,e);return`${e.path}?url=${encodeURIComponent(t)}&w=${a}&q=${m}${t.startsWith("/")&&l?`&dpl=${l}`:""}`}i.__next_img_default=!0;let o=i},65856,(e,t,a)=>{"use strict";e.i(47167),Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"RouterContext",{enumerable:!0,get:function(){return r}});let r=(e.r(55682)._(e.r(71645))).default.createContext(null)},98879,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"default",{enumerable:!0,get:function(){return l}});let r=e.r(71645),n="u"<typeof window,i=n?()=>{}:r.useLayoutEffect,o=n?()=>{}:r.useEffect;function l(e){let{headManager:t,reduceComponentsToState:a}=e;function l(){if(t&&t.mountedInstances){let e=r.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));t.updateHead(a(e))}}return n&&(t?.mountedInstances?.add(e.children),l()),i(()=>(t?.mountedInstances?.add(e.children),()=>{t?.mountedInstances?.delete(e.children)})),i(()=>(t&&(t._pendingUpdate=l),()=>{t&&(t._pendingUpdate=l)})),o(()=>(t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null),()=>{t&&t._pendingUpdate&&(t._pendingUpdate(),t._pendingUpdate=null)})),null}}]);