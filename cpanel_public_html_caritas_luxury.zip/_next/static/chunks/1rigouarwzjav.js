(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,25655,e=>{"use strict";var t=e.i(43476),r=e.i(25164),i=e.i(22016);let n=[{id:1,img:"/wp-content/uploads/shop page/blog1.png",date:"May 11, 2024",categories:"Cushion , Emerald",title:"The sparkle story by the journey through diamond manufacturing",href:"/why-lab-grown"},{id:2,img:"/wp-content/uploads/shop page/blog2.png",date:"May 8, 2024",categories:"Marquise , Pear",title:"Carving perfection by the art and science of diamond manufacture",href:"/why-lab-grown"},{id:3,img:"/wp-content/uploads/shop page/blog3.png",date:"May 7, 2024",categories:"Cutting , Diamond",title:"Shaping brilliance by the intricate world of diamond production",href:"/why-lab-grown"}];e.s(["default",0,function(){return(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"70px 24px 90px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .blogs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .blog-item {
          display: flex;
          flex-direction: column;
          text-decoration: none;
          color: inherit;
          cursor: pointer;
        }

        .blog-img-container {
          position: relative;
          width: 100%;
          aspect-ratio: 395 / 265;
          border-radius: 18px;
          overflow: hidden;
          background: #e8e3dc;
          border: 1px solid rgba(0, 0, 0, 0.08);
          margin-bottom: 18px;
        }

        .blog-img-container img {
          transition: transform 0.45s ease;
        }

        .blog-item:hover .blog-img-container img {
          transform: scale(1.06);
        }

        .blog-title {
          margin: 10px 0 0;
          font-size: 19px;
          font-weight: 700;
          color: #111111;
          font-family: 'Playfair Display', Georgia, serif;
          line-height: 1.35;
          transition: color 0.25s ease;
        }

        .blog-item:hover .blog-title {
          color: #BFA37C;
        }

        @media (max-width: 900px) {
          .blogs-grid {
            grid-template-columns: 1fr !important;
            gap: 36px !important;
          }
          .blog-img-container {
            aspect-ratio: 16 / 10 !important;
          }
        }
      `}),(0,t.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:[(0,t.jsxs)("div",{style:{marginBottom:"40px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"12px",marginBottom:"10px"},children:[(0,t.jsx)("span",{style:{width:"46px",height:"1.5px",background:"#222222",display:"inline-block"}}),(0,t.jsx)("span",{style:{fontSize:"11px",letterSpacing:"1.8px",textTransform:"uppercase",color:"#222222",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:600},children:"LATEST NEWS"})]}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(32px, 4.5vw, 50px)",fontWeight:700,fontFamily:"'Playfair Display', Georgia, serif",color:"#111111",lineHeight:1.15,letterSpacing:"-0.5px"},children:"Explore all our blogs"})]}),(0,t.jsx)("div",{className:"blogs-grid",children:n.map(e=>(0,t.jsxs)(i.default,{href:e.href,className:"blog-item",children:[(0,t.jsx)("div",{className:"blog-img-container",children:(0,t.jsx)(r.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover"},sizes:"(max-width: 900px) 100vw, 33vw"})}),(0,t.jsxs)("div",{style:{fontSize:"12.5px",color:"#666666",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:500,display:"flex",alignItems:"center",gap:"6px"},children:[(0,t.jsx)("span",{children:e.date}),(0,t.jsx)("span",{children:"•"}),(0,t.jsx)("span",{children:e.categories})]}),(0,t.jsx)("h3",{className:"blog-title",children:e.title})]},e.id))})]})]})}])},89800,e=>{"use strict";var t=e.i(43476),r=e.i(71645),i=e.i(25164),n=e.i(22016),a=e.i(21551);let o=[{img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Diamond ring",items:"7 Items",href:"/diamonds",textDark:!1},{img:"/wp-content/uploads/shop page/banner-02.jpg",title:"Diamond bracelets",items:"3 Items",href:"/diamonds",textDark:!0},{img:"/wp-content/uploads/shop page/bannerr-03.jpg",title:"Necklace sets",items:"3 Items",href:"/diamonds",textDark:!1},{img:"/wp-content/uploads/shop page/banner-04.jpg",title:"Earrings",items:"5 Items",href:"/diamonds/white",textDark:!1}];e.s(["default",0,function(){let[e,s]=(0,r.useState)(o);return(0,r.useEffect)(()=>{!async function(){try{let e=await (0,a.getCategories)();if(e&&e.length>0){let t=e.filter(e=>!1!==e.published);if(t.length>0){let e=t.map(e=>({img:e.image||"/wp-content/uploads/shop page/banner-01.jpg",title:e.name,items:e.itemsCountText||"5 Items",href:"/diamonds",textDark:!!e.textDark}));s(e)}}}catch(e){console.error("Categories fallback to default:",e)}}()},[]),(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"28px 24px 56px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .cat-grid {
          display: flex;
          gap: 12px;
          max-width: 1200px;
          margin: 0 auto;
          align-items: stretch;
        }

        .cat-item {
          position: relative;
          border-radius: 16px;
          overflow: hidden;
          flex: 1;
          height: 280px;
          display: block;
          text-decoration: none;
          cursor: pointer;
          transition: transform 0.3s, box-shadow 0.3s;
        }
        .cat-item:hover {
          transform: translateY(-5px);
          box-shadow: 0 16px 40px rgba(0,0,0,0.18);
        }

        /* text label sits top-left */
        .cat-text {
          position: absolute;
          top: 16px;
          left: 18px;
          z-index: 3;
        }
        .cat-text-title {
          display: block;
          font-size: 15px;
          font-weight: 700;
          font-family: var(--title-fonts, 'Readex Pro', sans-serif);
          line-height: 1.25;
          margin-bottom: 5px;
        }
        .cat-text-count {
          display: block;
          font-size: 12px;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
        }

        @media (max-width: 680px) {
          .cat-grid { flex-wrap: wrap; }
          .cat-item { flex: none; width: calc(50% - 6px); height: 200px; }
        }
        @media (max-width: 400px) {
          .cat-item { width: 100%; height: 220px; }
        }
      `}),(0,t.jsx)("div",{className:"cat-grid",children:e.map(e=>{let r=e.textDark?"#111111":"#ffffff",a=e.textDark?"linear-gradient(160deg, rgba(255,255,255,0.45) 0%, transparent 50%)":"linear-gradient(160deg, rgba(0,0,0,0.38) 0%, transparent 55%)";return(0,t.jsxs)(n.default,{href:e.href,className:"cat-item",children:[(0,t.jsx)(i.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover",objectPosition:"center"},sizes:"(max-width: 680px) 45vw, 25vw"}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:a}}),(0,t.jsxs)("div",{className:"cat-text",children:[(0,t.jsx)("span",{className:"cat-text-title",style:{color:r},children:e.title}),(0,t.jsx)("span",{className:"cat-text-count",style:{color:r,opacity:.82},children:e.items})]})]},e.title)})})]})}])},95953,e=>{"use strict";var t=e.i(43476),r=e.i(25164),i=e.i(22016);e.s(["default",0,function(){return(0,t.jsxs)("section",{style:{position:"relative",width:"100%",minHeight:"88vh",background:"#080808",display:"flex",alignItems:"center",overflow:"hidden",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .hero-shine-btn {
          display: inline-block;
          padding: 12px 32px;
          background: transparent;
          border: 1.5px solid rgba(255,255,255,0.5);
          color: #ffffff;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
          font-size: 12px;
          letter-spacing: 3px;
          text-transform: uppercase;
          text-decoration: none;
          transition: background 0.3s, border-color 0.3s;
          cursor: pointer;
        }
        .hero-shine-btn:hover {
          background: rgba(255,255,255,0.12);
          border-color: #ffffff;
        }
        .hero-shine-word {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(40px, 6.5vw, 92px);
          font-weight: 700;
          line-height: 0.9;
          color: #ffffff;
          letter-spacing: -2px;
          text-transform: uppercase;
        }
        @media (max-width: 900px) {
          .hero-inner { flex-direction: column !important; padding-top: 120px !important; }
          .hero-left-text  { align-items: center !important; text-align: center !important; }
          .hero-right-text { align-items: center !important; text-align: center !important; }
          .hero-img-col { width: 70vw !important; height: 260px !important; }
        }
        @media (max-width: 540px) {
          .hero-img-col { width: 90vw !important; height: 200px !important; }
        }
      `}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to right, #080808 0%, transparent 18%, transparent 82%, #080808 100%)",zIndex:1,pointerEvents:"none"}}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to bottom, #080808 0%, transparent 15%, transparent 85%, #080808 100%)",zIndex:1,pointerEvents:"none"}}),(0,t.jsxs)("div",{className:"hero-inner",style:{position:"relative",zIndex:2,width:"100%",maxWidth:"1280px",margin:"0 auto",padding:"120px 40px 90px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:"32px",boxSizing:"border-box"},children:[(0,t.jsxs)("div",{className:"hero-left-text",style:{display:"flex",flexDirection:"column",alignItems:"flex-start",gap:"18px",flex:"1",minWidth:0},children:[(0,t.jsx)("span",{className:"hero-shine-word",children:"SHINE"}),(0,t.jsx)("span",{className:"hero-shine-word",children:"BRIGHT"}),(0,t.jsx)("p",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px",lineHeight:1.8,maxWidth:"210px",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',margin:"6px 0"},children:"Lab-grown diamonds in extraordinary colour. Discover our signature pink and white collection."}),(0,t.jsx)(i.default,{href:"/diamonds/pink",className:"hero-shine-btn",children:"EXPLORE"})]}),(0,t.jsx)("div",{className:"hero-img-col",style:{position:"relative",width:"38%",height:"340px",flexShrink:0},children:(0,t.jsx)(r.default,{src:"/wp-content/uploads/shop page/header picture.png",alt:"Brilliant cut diamond",fill:!0,priority:!0,style:{objectFit:"contain",objectPosition:"center"},sizes:"(max-width: 900px) 70vw, 38vw"})}),(0,t.jsxs)("div",{className:"hero-right-text",style:{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:"18px",flex:"1",minWidth:0},children:[(0,t.jsx)("span",{className:"hero-shine-word",style:{textAlign:"right"},children:"DAY AND"}),(0,t.jsx)("span",{className:"hero-shine-word",style:{textAlign:"right"},children:"NIGHT"}),(0,t.jsx)("p",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px",lineHeight:1.8,maxWidth:"210px",textAlign:"right",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',margin:"6px 0"},children:"Lab-grown diamonds. No diamond mining. Crafted for every moment."})]})]})]})}])},87711,e=>{"use strict";var t=e.i(43476),r=e.i(71645),i=e.i(25164),n=e.i(22016),a=e.i(21551);let o=["All","Rings","Earrings","Diamonds","Necklaces","Bracelets"],s=[{id:1,img:"/wp-content/uploads/shop page/pro-21-300x300.png",title:"Pink Morganite Butterfly Ring",price:"$4,200",originalPrice:"$5,190",discount:"-19%",rating:4.8,tab:"Rings"},{id:2,img:"/wp-content/uploads/shop page/pro-03-300x300.jpg",title:"Fancy Pink Drop Earrings",price:"$2,100",originalPrice:"$2,599",discount:"-19%",rating:4.6,tab:"Earrings"},{id:3,img:"/wp-content/uploads/shop page/pro-05-300x300.jpg",title:"Teal Drop Ring & Earring Set",price:"$3,600",originalPrice:null,discount:null,rating:4.9,tab:"Rings"},{id:4,img:"/wp-content/uploads/shop page/pro-04-300x300.jpg",title:"Pink Cluster Necklace",price:"$600",originalPrice:null,discount:null,rating:4.5,tab:"Necklaces"},{id:5,img:"/wp-content/uploads/shop page/pro-07-300x300.jpg",title:"Emerald Serpentine Ring",price:"$4,800",originalPrice:null,discount:null,rating:5,tab:"Rings"},{id:6,img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Emerald Eternity Band",price:"$2,800",originalPrice:null,discount:null,rating:4.7,tab:"Rings"}];function l({rating:e}){return(0,t.jsxs)("span",{style:{color:"#BFA37C",fontSize:"12px"},children:["★".repeat(Math.floor(e)),"☆".repeat(5-Math.floor(e)),(0,t.jsxs)("span",{style:{color:"#888",marginLeft:"4px",fontSize:"11px"},children:["(",e,")"]})]})}e.s(["default",0,function(){let[e,d]=(0,r.useState)("All"),[c,p]=(0,r.useState)(s);(0,r.useEffect)(()=>{!async function(){try{let e=await (0,a.getProducts)({publishedOnly:!0});if(e&&e.length>0){let t=e.filter(e=>!1!==e.isNewArrival).map(e=>{let t=e.salePrice?`$${e.salePrice.toLocaleString()}`:null,r=e.salePrice&&e.price<e.salePrice?`-${Math.round((e.salePrice-e.price)/e.salePrice*100)}%`:null;return{id:e.id,img:e.images?.[0]?.url||"/wp-content/uploads/shop page/pro-21-300x300.png",title:e.name,price:`$${(e.price||0).toLocaleString()}`,originalPrice:t,discount:r,rating:e.rating||5,tab:e.category||"Rings"}});t.length>0&&p(t)}}catch(e){console.error("Using default products fallback:",e)}}()},[]);let f="All"===e?c:c.filter(t=>t.tab===e);return(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"70px 0 80px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .arrivals-tab {
          background: transparent;
          border: none;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
          font-size: 13px;
          cursor: pointer;
          padding: 6px 0;
          position: relative;
          transition: color 0.2s;
          white-space: nowrap;
        }
        .arrivals-tab.active { color: #111 !important; }
        .arrivals-tab.active::after {
          content: '';
          position: absolute;
          bottom: 0; left: 0; right: 0;
          height: 2px;
          background: #111;
        }
        .product-card {
          background: #ffffff;
          border-radius: 12px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          transition: box-shadow 0.2s;
        }
        .product-card:hover { box-shadow: 0 8px 32px rgba(0,0,0,0.12); }
        .product-card-img-wrap {
          position: relative;
          width: 100%;
          aspect-ratio: 1 / 1;
          overflow: hidden;
        }
        .arrivals-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }
        @media (max-width: 900px) {
          .arrivals-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (max-width: 540px) {
          .arrivals-grid { grid-template-columns: 1fr !important; }
        }
      `}),(0,t.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto",padding:"0 24px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"flex-end",justifyContent:"space-between",flexWrap:"wrap",gap:"16px",marginBottom:"36px"},children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{style:{margin:"0 0 8px",fontSize:"11px",letterSpacing:"2px",textTransform:"uppercase",color:"#BFA37C",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:"— EXPLORE NOW"}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts,"Readex Pro",sans-serif)',color:"#111",lineHeight:1.1},children:"New Arrivals"})]}),(0,t.jsx)("div",{style:{display:"flex",gap:"24px",overflowX:"auto",paddingBottom:"4px"},children:o.map(r=>(0,t.jsx)("button",{className:`arrivals-tab${e===r?" active":""}`,style:{color:e===r?"#111":"#888"},onClick:()=>d(r),children:r},r))})]}),(0,t.jsx)("div",{className:"arrivals-grid",children:f.map(e=>(0,t.jsx)(n.default,{href:"/diamonds",style:{textDecoration:"none",color:"inherit"},children:(0,t.jsxs)("div",{className:"product-card",children:[(0,t.jsxs)("div",{className:"product-card-img-wrap",children:[(0,t.jsx)(i.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover",transition:"transform 0.4s"},sizes:"(max-width: 540px) 90vw, (max-width: 900px) 45vw, 30vw",onMouseEnter:e=>{e.currentTarget.style.transform="scale(1.05)"},onMouseLeave:e=>{e.currentTarget.style.transform="scale(1)"}}),e.discount&&(0,t.jsx)("span",{style:{position:"absolute",top:"12px",left:"12px",background:"#ff5722",color:"#fff",fontSize:"11px",fontWeight:700,padding:"3px 8px",borderRadius:"4px",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:e.discount})]}),(0,t.jsxs)("div",{style:{padding:"16px"},children:[(0,t.jsx)(l,{rating:e.rating}),(0,t.jsx)("h4",{style:{margin:"8px 0 6px",fontSize:"14px",fontWeight:600,color:"#111",fontFamily:'var(--title-fonts,"Readex Pro",sans-serif)',lineHeight:1.3},children:e.title}),(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[(0,t.jsx)("span",{style:{fontSize:"15px",fontWeight:700,color:"#111"},children:e.price}),e.originalPrice&&(0,t.jsx)("span",{style:{fontSize:"13px",color:"#aaa",textDecoration:"line-through"},children:e.originalPrice})]})]})]})},e.id))}),(0,t.jsx)("div",{style:{textAlign:"center",marginTop:"48px"},children:(0,t.jsx)(n.default,{href:"/diamonds",style:{display:"inline-block",padding:"14px 40px",background:"#111111",color:"#fff",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',fontSize:"12px",letterSpacing:"2px",textTransform:"uppercase",textDecoration:"none",borderRadius:"4px",transition:"background 0.2s"},children:"LOAD MORE PRODUCTS"})})]})]})}])},20184,e=>{"use strict";var t=e.i(43476),r=e.i(71645),i=e.i(25164),n=e.i(22016),a=e.i(21551);let o=[{id:1,img:"/wp-content/uploads/shop page/pro-21-300x300.png",title:"Pink Morganite Butterfly Ring",price:"From $4,200",badge:"NEW",rating:4.9},{id:2,img:"/wp-content/uploads/shop page/pro-03-300x300.jpg",title:"Purple Diamond Hoop Earrings",price:"From $2,100",badge:"HOT",rating:4.8},{id:3,img:"/wp-content/uploads/shop page/pro-05-300x300.jpg",title:"Teal Drop Halo Ring",price:"From $77.00",badge:"NEW",rating:5},{id:4,img:"/wp-content/uploads/shop page/pro-04-300x300.jpg",title:"Pink Cluster Necklace",price:"From $600",badge:null,rating:4.7},{id:5,img:"/wp-content/uploads/shop page/banner-02.jpg",title:"Diamond Pavé Band",price:"From $900",badge:null,rating:4.9},{id:6,img:"/wp-content/uploads/shop page/pro-07-300x300.jpg",title:"Emerald Serpentine Ring",price:"From $1,742",badge:"TRENDING",rating:5},{id:7,img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Emerald Eternity Band",price:"From $2,800",badge:null,rating:4.8},{id:8,img:"/wp-content/uploads/shop page/banner-04.jpg",title:"Rainbow Gemstone Huggies",price:"From $1,250",badge:"BESTSELLER",rating:4.9},{id:9,img:"/wp-content/uploads/shop page/bannerr-03.jpg",title:"Sapphire Collar Necklace Set",price:"From $3,400",badge:null,rating:5}];e.s(["default",0,function(){let[e,s]=(0,r.useState)(o),l="#BFA37C";(0,r.useEffect)(()=>{!async function(){try{let e=await (0,a.getProducts)({publishedOnly:!0});if(e&&e.length>0){let t=e.filter(e=>e.isTrending||e.isFeatured),r=(t.length>0?t:e).map(e=>({id:e.id,img:e.images?.[0]?.url||"/wp-content/uploads/shop page/pro-21-300x300.png",title:e.name,price:`From $${(e.price||0).toLocaleString()}`,badge:e.badge||(e.isNewArrival?"NEW":null),rating:e.rating||5}));r.length>0&&s(r)}}catch(e){console.error("Trending products fallback to default:",e)}}()},[]);let d=[...e,...e];return(0,t.jsxs)("section",{style:{background:"#ffffff",padding:"70px 0 80px",boxSizing:"border-box",overflow:"hidden",position:"relative"},children:[(0,t.jsx)("style",{children:`
        @keyframes marqueeInfinite {
          0% {
            transform: translate3d(0, 0, 0);
          }
          100% {
            transform: translate3d(-50%, 0, 0);
          }
        }

        .infinite-marquee-container {
          position: relative;
          width: 100%;
          overflow: hidden;
          padding: 10px 0 20px;
        }

        .infinite-marquee-track {
          display: flex;
          gap: 22px;
          width: max-content;
          animation: marqueeInfinite 38s linear infinite;
          will-change: transform;
        }

        .infinite-marquee-container:hover .infinite-marquee-track {
          animation-play-state: paused;
        }

        .trending-card {
          flex: 0 0 250px;
          width: 250px;
          background: #ffffff;
          border-radius: 14px;
          overflow: hidden;
          text-decoration: none;
          color: inherit;
          display: flex;
          flex-direction: column;
          box-shadow: 0 4px 18px rgba(0, 0, 0, 0.05);
          transition: transform 0.3s cubic-bezier(0.2, 0, 0, 1), box-shadow 0.3s ease;
          border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .trending-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 14px 34px rgba(0, 0, 0, 0.12);
        }

        .trending-card-img-wrap {
          position: relative;
          width: 100%;
          aspect-ratio: 1 / 1;
          background: #faf8f5;
          overflow: hidden;
        }

        .trending-card-img-wrap img {
          transition: transform 0.45s ease;
        }

        .trending-card:hover .trending-card-img-wrap img {
          transform: scale(1.08);
        }

        .edge-fade-left {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          width: 80px;
          background: linear-gradient(to right, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
          z-index: 5;
          pointer-events: none;
        }

        .edge-fade-right {
          position: absolute;
          top: 0;
          bottom: 0;
          right: 0;
          width: 80px;
          background: linear-gradient(to left, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
          z-index: 5;
          pointer-events: none;
        }

        @media (max-width: 600px) {
          .trending-card {
            flex: 0 0 200px;
            width: 200px;
          }
          .edge-fade-left, .edge-fade-right {
            width: 30px;
          }
        }
      `}),(0,t.jsx)("div",{style:{maxWidth:"1200px",margin:"0 auto",padding:"0 24px 36px"},children:(0,t.jsxs)("div",{style:{display:"flex",alignItems:"flex-end",justifyContent:"space-between",flexWrap:"wrap",gap:"12px"},children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{style:{margin:"0 0 8px",fontSize:"11px",letterSpacing:"2px",textTransform:"uppercase",color:l,fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:600},children:"— TRENDING NOW"}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#111111",lineHeight:1.1},children:"Featured Products"})]}),(0,t.jsx)(n.default,{href:"/diamonds",style:{fontSize:"13px",fontWeight:600,color:"#111111",textDecoration:"none",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',display:"inline-flex",alignItems:"center",gap:"6px",borderBottom:"1px solid #111111",paddingBottom:"2px"},children:"View all →"})]})}),(0,t.jsxs)("div",{className:"infinite-marquee-container",children:[(0,t.jsx)("div",{className:"edge-fade-left"}),(0,t.jsx)("div",{className:"edge-fade-right"}),(0,t.jsx)("div",{className:"infinite-marquee-track",children:d.map((e,r)=>(0,t.jsxs)(n.default,{href:"/diamonds",className:"trending-card",children:[(0,t.jsxs)("div",{className:"trending-card-img-wrap",children:[(0,t.jsx)(i.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover"},sizes:"250px"}),e.badge&&(0,t.jsx)("span",{style:{position:"absolute",top:"12px",left:"12px",background:"HOT"===e.badge?"#e53935":"BESTSELLER"===e.badge?"#111111":"#ff5722",color:"#ffffff",fontSize:"10px",fontWeight:800,letterSpacing:"0.5px",padding:"3px 8px",borderRadius:"4px",textTransform:"uppercase",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',zIndex:2},children:e.badge})]}),(0,t.jsxs)("div",{style:{padding:"16px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"4px",marginBottom:"6px"},children:[(0,t.jsx)("span",{style:{color:l,fontSize:"11px"},children:"★"}),(0,t.jsx)("span",{style:{fontSize:"11px",color:"#777777",fontWeight:600,fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)'},children:e.rating})]}),(0,t.jsx)("h4",{style:{margin:"0 0 6px",fontSize:"14px",fontWeight:600,color:"#111111",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',lineHeight:1.35,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},title:e.title,children:e.title}),(0,t.jsx)("p",{style:{margin:0,fontSize:"13px",fontWeight:700,color:"#222222",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)'},children:e.price})]})]},`${e.id}-${r}`))})]})]})}])},21551,21066,e=>{"use strict";e.i(36180);var t=e.i(54542);e.s(["f",()=>t.aS],21066);var t=t,r=e.i(99689),i=e.i(63802),n=e.i(28846);e.i(61086);var a=e.i(27215),o=e.i(60664);function s(e,t){let r=Array.isArray(t.images)?t.images.map(e=>"string"==typeof e?{url:e,isMain:!1,alt:t.name||""}:{url:e.url||"",isMain:!!e.isMain,alt:e.alt||t.name||""}):[],i=void 0!==t.published?!!t.published:"published"===t.status||void 0===t.status;return{id:e,name:t.name||"Untitled Product",slug:t.slug||e,category:t.category||"General",subcategory:t.subcategory||"",description:t.description||"",shortDescription:t.shortDescription||"",price:"number"==typeof t.price?t.price:t.priceAed||0,salePrice:t.salePrice||null,sku:t.sku||t.numericId?.toString()||e,stock:void 0!==t.stock?Number(t.stock):10,availability:t.availability||(t.stock>0?"in_stock":"out_of_stock"),weight:t.weight||(t.grams?`${t.grams}g`:""),images:r,specifications:t.specifications||[],attributes:t.attributes||[],isFeatured:!!(t.featured??t.isFeatured),isNewArrival:!!(t.isNewArrival??!0),isTrending:!!(t.isTrending??!0),badge:t.badge||(t.featured?"FEATURED":null),rating:t.rating||5,published:i,seoTitle:t.seoTitle||t.name,seoDescription:t.seoDescription||t.description,createdAt:t.createdAt,updatedAt:t.updatedAt}}async function l(e){try{let r=(0,t.aS)(o.db,"products"),n=(0,i.z)(r);e?.limitCount&&(n=(0,i.z)(n,(0,i.C)(e.limitCount)));let a=await (0,i.W)(n),l=[];return a.forEach(e=>{l.push(s(e.id,e.data()))}),e?.publishedOnly&&(l=l.filter(e=>e.published)),e?.category&&"All"!==e.category&&(l=l.filter(t=>t.category?.toLowerCase()===e.category?.toLowerCase())),l}catch(e){return console.error("Error fetching products from Firebase:",e),[]}}async function d(e){try{let t=(0,r.f)(o.db,"products",e),n=await (0,i.H)(t);if(!n.exists())return null;return s(n.id,n.data())}catch(e){return console.error("Error fetching product by ID:",e),null}}async function c(e){let r=(0,t.aS)(o.db,"products");return(await (0,i.n)(r,{...e,createdAt:(0,n.f)(),updatedAt:(0,n.f)()})).id}async function p(e,t){let a=(0,r.f)(o.db,"products",e);await (0,i.F)(a,{...t,updatedAt:(0,n.f)()})}async function f(e){let t=(0,r.f)(o.db,"products",e);await (0,i.d)(t)}async function u(){try{let e=(0,t.aS)(o.db,"categories"),r=await (0,i.W)(e),n=[];return r.forEach(e=>{var t,r;n.push({id:t=e.id,name:(r=e.data()).name||"Category",slug:r.slug||t,description:r.description||"",image:r.image||r.imageUrl||"/wp-content/uploads/shop page/banner-01.jpg",itemsCountText:r.itemsCountText||`${r.itemsCount||0} Items`,textDark:!!r.textDark,displayOrder:r.displayOrder??r.order??0,published:void 0!==r.published?!!r.published:!1!==r.active,subcategories:r.subcategories||[]})}),n.sort((e,t)=>(e.displayOrder||0)-(t.displayOrder||0))}catch(e){return console.error("Error fetching categories from Firebase:",e),[]}}async function g(e){let r=(0,t.aS)(o.db,"categories");return(await (0,i.n)(r,{...e,createdAt:(0,n.f)(),updatedAt:(0,n.f)()})).id}async function h(e,t){let a=(0,r.f)(o.db,"categories",e);await (0,i.F)(a,{...t,updatedAt:(0,n.f)()})}async function x(e){let t=(0,r.f)(o.db,"categories",e);await (0,i.d)(t)}async function m(){try{let e=(0,r.f)(o.db,"settings","shop"),t=await (0,i.H)(e);if(t.exists()||(t=await (0,i.H)((0,r.f)(o.db,"shopSettings","general"))),!t.exists())return null;return{id:t.id,...t.data()}}catch(e){return console.error("Error fetching shop settings:",e),null}}async function b(e){let t=(0,r.f)(o.db,"settings","shop");await (0,i.r)(t,{...e,updatedAt:(0,n.f)()},{merge:!0})}async function y(){try{let e=(0,r.f)(o.db,"settings","websiteContent"),t=await (0,i.H)(e);if(t.exists()||(t=await (0,i.H)((0,r.f)(o.db,"websiteContent","general"))),!t.exists())return null;return{id:t.id,...t.data()}}catch(e){return console.error("Error fetching website content:",e),null}}async function w(e){let t=(0,r.f)(o.db,"settings","websiteContent");await (0,i.r)(t,{...e,updatedAt:(0,n.f)()},{merge:!0})}async function v(){try{let e=(0,r.f)(o.db,"settings","navigation"),t=await (0,i.H)(e);if(t.exists()||(t=await (0,i.H)((0,r.f)(o.db,"navigation","mainMenu"))),t.exists()&&t.data().items)return t.data().items;return[]}catch(e){return console.error("Error fetching navigation:",e),[]}}async function j(e){let t=(0,r.f)(o.db,"settings","navigation");await (0,i.r)(t,{items:e,updatedAt:(0,n.f)()},{merge:!0})}async function S(){try{let e=(0,r.f)(o.db,"settings","footer"),t=await (0,i.H)(e);if(t.exists()||(t=await (0,i.H)((0,r.f)(o.db,"footer","config"))),!t.exists())return null;return{id:t.id,...t.data()}}catch(e){return console.error("Error fetching footer config:",e),null}}async function N(e){let t=(0,r.f)(o.db,"settings","footer");await (0,i.r)(t,{...e,updatedAt:(0,n.f)()},{merge:!0})}async function k(){try{let e=(0,t.aS)(o.db,"orders"),r=await (0,i.W)(e),n=[];return r.forEach(e=>{n.push({id:e.id,...e.data()})}),n.sort((e,t)=>(t.createdAt?.seconds||0)-(e.createdAt?.seconds||0))}catch(e){return console.error("Error fetching orders:",e),[]}}async function E(e,t,a){let s=(0,r.f)(o.db,"orders",e),l={orderStatus:t,updatedAt:(0,n.f)()};a&&(l.paymentStatus=a),await (0,i.F)(s,l)}async function P(){try{let e=(0,t.aS)(o.db,"customers"),r=await (0,i.W)(e),n=[];return r.forEach(e=>{n.push({id:e.id,...e.data()})}),n}catch(e){return console.error("Error fetching customers:",e),[]}}async function C(){try{let e=(0,t.aS)(o.db,"adminUsers"),r=await (0,i.W)(e),n=[];return r.forEach(e=>{let t=e.data();n.push({uid:e.id,email:t.email||"",displayName:t.name||t.displayName||t.email?.split("@")[0]||"Admin",role:"owner"===t.role?"super_admin":t.role||"admin",createdAt:t.createdAt})}),n}catch(e){return console.error("Error fetching admin users:",e),[]}}async function A(e,t="admin",a){let s=(0,r.f)(o.db,"adminUsers",e);await (0,i.r)(s,{email:e,displayName:a||e.split("@")[0],role:"super_admin"===t?"owner":t,createdAt:(0,n.f)()})}async function F(e,t="products"){let r=e.name.replace(/[^a-zA-Z0-9.-]/g,"_"),i=`${t}/${Date.now()}-${r}`,n=(0,a.C)(o.storage,i),s=await (0,a.u)(n,e);return await (0,a.k)(s.ref)}e.s(["addAdminUser",0,A,"createCategory",0,g,"createProduct",0,c,"deleteCategory",0,x,"deleteProduct",0,f,"getAdminUsers",0,C,"getCategories",0,u,"getCustomers",0,P,"getFooterConfig",0,S,"getNavigation",0,v,"getOrders",0,k,"getProductById",0,d,"getProducts",0,l,"getShopSettings",0,m,"getWebsiteContent",0,y,"updateCategory",0,h,"updateFooterConfig",0,N,"updateNavigation",0,j,"updateOrderStatus",0,E,"updateProduct",0,p,"updateShopSettings",0,b,"updateWebsiteContent",0,w,"uploadFileToStorage",0,F],21551)},99689,28846,e=>{"use strict";var t=e.i(54542);e.s(["f",()=>t.s],99689),e.s(["f",()=>t.b7],28846)},22016,(e,t,r)=>{"use strict";e.i(47167),Object.defineProperty(r,"__esModule",{value:!0});var i={default:function(){return m},useLinkStatus:function(){return y}};for(var n in i)Object.defineProperty(r,n,{enumerable:!0,get:i[n]});let a=e.r(90809),o=e.r(43476),s=a._(e.r(71645)),l=e.r(95057),d=e.r(8372),c=e.r(18581),p=e.r(18967),f=e.r(5550),u=e.r(88540),g=e.r(91949),h=e.r(73668),x=e.r(9396);function m(t){var r;let i,n,a,[m,y]=(0,s.useOptimistic)(g.IDLE_LINK_STATUS),w=(0,s.useRef)(null),{href:v,as:j,children:S,prefetch:N=null,passHref:k,replace:E,shallow:P,scroll:C,onClick:A,onMouseEnter:F,onTouchStart:T,legacyBehavior:z=!1,onNavigate:D,transitionTypes:R,ref:$,unstable_dynamicOnHover:I,...O}=t;i=S,z&&("string"==typeof i||"number"==typeof i)&&(i=(0,o.jsx)("a",{children:i}));let W=s.default.useContext(d.AppRouterContext),L=!1!==N,B=!1===N?"none":!0===N?"full":"auto",M="none"!==B?"auto"===B?x.FetchStrategy.PPR:x.FetchStrategy.Full:x.FetchStrategy.PPR,_="string"==typeof(r=j||v)?r:(0,l.formatUrl)(r);if(z){if(i?.$$typeof===Symbol.for("react.lazy"))throw Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag.");n=s.default.Children.only(i)}let U=z?n&&"object"==typeof n&&n.ref:$,H,q=s.default.useCallback(e=>(null!==W&&(w.current=(0,g.mountLinkInstance)(e,_,W,M,L,y,H)),()=>{w.current&&((0,g.unmountLinkForCurrentNavigation)(w.current),w.current=null),(0,g.unmountPrefetchableInstance)(e)}),[L,_,W,M,y,H]),G={ref:(0,c.useMergedRef)(q,U),onClick(t){z||"function"!=typeof A||A(t),z&&n.props&&"function"==typeof n.props.onClick&&n.props.onClick(t),!W||t.defaultPrevented||function(t,r,i,n,a,o,s,l="none"){if("u">typeof window){let d,{nodeName:c}=t.currentTarget;if("A"===c.toUpperCase()&&((d=t.currentTarget.getAttribute("target"))&&"_self"!==d||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||t.nativeEvent&&2===t.nativeEvent.which)||t.currentTarget.hasAttribute("download"))return;if(!(0,h.isLocalURL)(r)){n&&(t.preventDefault(),location.replace(r));return}if(t.preventDefault(),o){let e=!1;if(o({preventDefault:()=>{e=!0}}),e)return}let{navigate:p}=e.r(32916);p(r,n?"replace":"push",!1===a?u.ScrollBehavior.NoScroll:u.ScrollBehavior.Default,i.current,s,l)}}(t,_,w,E,C,D,R,B)},onMouseEnter(e){z||"function"!=typeof F||F(e),z&&n.props&&"function"==typeof n.props.onMouseEnter&&n.props.onMouseEnter(e),W&&L&&(0,g.onNavigationIntent)(e.currentTarget,!0===I)},onTouchStart:function(e){z||"function"!=typeof T||T(e),z&&n.props&&"function"==typeof n.props.onTouchStart&&n.props.onTouchStart(e),W&&L&&(0,g.onNavigationIntent)(e.currentTarget,!0===I)}};return(0,p.isAbsoluteUrl)(_)?G.href=_:z&&!k&&("a"!==n.type||"href"in n.props)||(G.href=(0,f.addBasePath)(_)),a=z?s.default.cloneElement(n,G):(0,o.jsx)("a",{...O,...G,children:i}),(0,o.jsx)(b.Provider,{value:m,children:a})}let b=(0,s.createContext)(g.IDLE_LINK_STATUS),y=()=>(0,s.useContext)(b);("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},18581,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"useMergedRef",{enumerable:!0,get:function(){return n}});let i=e.r(71645);function n(e,t){let r=(0,i.useRef)(null),n=(0,i.useRef)(null);return(0,i.useCallback)(i=>{if(null===i){let e=r.current;e&&(r.current=null,e());let t=n.current;t&&(n.current=null,t())}else e&&(r.current=a(e,i)),t&&(n.current=a(t,i))},[e,t])}function a(e,t){if("function"!=typeof e)return e.current=t,()=>{e.current=null};{let r=e(t);return"function"==typeof r?r:()=>e(null)}}("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},95057,(e,t,r)=>{"use strict";e.i(47167),Object.defineProperty(r,"__esModule",{value:!0});var i={formatUrl:function(){return s},formatWithValidation:function(){return d},urlObjectKeys:function(){return l}};for(var n in i)Object.defineProperty(r,n,{enumerable:!0,get:i[n]});let a=e.r(90809)._(e.r(98183)),o=/https?|ftp|gopher|file/;function s(e){let{auth:t,hostname:r}=e,i=e.protocol||"",n=e.pathname||"",s=e.hash||"",l=e.query||"",d=!1;t=t?encodeURIComponent(t).replace(/%3A/i,":")+"@":"",e.host?d=t+e.host:r&&(d=t+(~r.indexOf(":")?`[${r}]`:r),e.port&&(d+=":"+e.port)),l&&"object"==typeof l&&(l=String(a.urlQueryToSearchParams(l)));let c=e.search||l&&`?${l}`||"";return i&&!i.endsWith(":")&&(i+=":"),e.slashes||(!i||o.test(i))&&!1!==d?(d="//"+(d||""),n&&"/"!==n[0]&&(n="/"+n)):d||(d=""),s&&"#"!==s[0]&&(s="#"+s),c&&"?"!==c[0]&&(c="?"+c),n=n.replace(/[?#]/g,encodeURIComponent),c=c.replace("#","%23"),`${i}${d}${n}${c}${s}`}let l=["auth","hash","host","hostname","href","path","pathname","port","protocol","query","search","slashes"];function d(e){return s(e)}},73668,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"isLocalURL",{enumerable:!0,get:function(){return a}});let i=e.r(18967),n=e.r(52817);function a(e){if(!(0,i.isAbsoluteUrl)(e))return!0;try{let t=(0,i.getLocationOrigin)(),r=new URL(e,t);return r.origin===t&&(0,n.hasBasePath)(r.pathname)}catch(e){return!1}}},18967,(e,t,r)=>{"use strict";e.i(47167),Object.defineProperty(r,"__esModule",{value:!0});var i={DecodeError:function(){return m},MiddlewareNotFoundError:function(){return v},MissingStaticPage:function(){return w},NormalizeError:function(){return b},PageNotFoundError:function(){return y},SP:function(){return h},ST:function(){return x},WEB_VITALS:function(){return a},execOnce:function(){return o},getDisplayName:function(){return p},getLocationOrigin:function(){return d},getURL:function(){return c},isAbsoluteUrl:function(){return l},isResSent:function(){return f},loadGetInitialProps:function(){return g},normalizeRepeatedSlashes:function(){return u},stringifyError:function(){return j}};for(var n in i)Object.defineProperty(r,n,{enumerable:!0,get:i[n]});let a=["CLS","FCP","INP","LCP","TTFB"];function o(e){let t,r=!1;return(...i)=>(r||(r=!0,t=e(...i)),t)}let s=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,l=e=>{let t=e.charCodeAt(0);return!!(t>=65&&t<=90||t>=97&&t<=122)&&s.test(e)};function d(){let{protocol:e,hostname:t,port:r}=window.location;return`${e}//${t}${r?":"+r:""}`}function c(){let{href:e}=window.location,t=d();return e.substring(t.length)}function p(e){return"string"==typeof e?e:e.displayName||e.name||"Unknown"}function f(e){return e.finished||e.headersSent}function u(e){let t=e.split("?");return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")}async function g(e,t){let r=t.res||t.ctx&&t.ctx.res;if(!e.getInitialProps)return t.ctx&&t.Component?{pageProps:await g(t.Component,t.ctx)}:{};let i=await e.getInitialProps(t);if(r&&f(r))return i;if(!i)throw Error(`"${p(e)}.getInitialProps()" should resolve to an object. But found "${i}" instead.`);return i}let h="u">typeof performance,x=h&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);class m extends Error{}class b extends Error{}class y extends Error{constructor(e){super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`}}class w extends Error{constructor(e,t){super(),this.message=`Failed to load static file for page: ${e} ${t}`}}class v extends Error{constructor(){super(),this.code="ENOENT",this.message="Cannot find the middleware module"}}function j(e){return JSON.stringify({message:e.message,stack:e.stack})}}]);