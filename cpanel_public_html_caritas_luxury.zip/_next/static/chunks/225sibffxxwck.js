(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,25655,e=>{"use strict";var t=e.i(43476),i=e.i(25164),n=e.i(22016);let a=[{id:1,img:"/wp-content/uploads/shop page/blog1.png",date:"May 11, 2024",categories:"Cushion , Emerald",title:"The sparkle story by the journey through diamond manufacturing",href:"/why-lab-grown"},{id:2,img:"/wp-content/uploads/shop page/blog2.png",date:"May 8, 2024",categories:"Marquise , Pear",title:"Carving perfection by the art and science of diamond manufacture",href:"/why-lab-grown"},{id:3,img:"/wp-content/uploads/shop page/blog3.png",date:"May 7, 2024",categories:"Cutting , Diamond",title:"Shaping brilliance by the intricate world of diamond production",href:"/why-lab-grown"}];e.s(["default",0,function(){return(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"70px 24px 90px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .blogs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 24px;
          max-width: 1200px;
          margin: 0 auto;
        }

        .blog-item {
          display: flex;
          flex-direction: column;
          text-decoration: none;
          color: inherit;
          cursor: pointer;
        }

        .blog-img-container {
          position: relative;
          width: 100%;
          aspect-ratio: 395 / 265;
          border-radius: 18px;
          overflow: hidden;
          background: #e8e3dc;
          border: 1px solid rgba(0, 0, 0, 0.08);
          margin-bottom: 18px;
        }

        .blog-img-container img {
          transition: transform 0.45s ease;
        }

        .blog-item:hover .blog-img-container img {
          transform: scale(1.06);
        }

        .blog-title {
          margin: 10px 0 0;
          font-size: 19px;
          font-weight: 700;
          color: #111111;
          font-family: 'Playfair Display', Georgia, serif;
          line-height: 1.35;
          transition: color 0.25s ease;
        }

        .blog-item:hover .blog-title {
          color: #BFA37C;
        }

        @media (max-width: 900px) {
          .blogs-grid {
            grid-template-columns: 1fr !important;
            gap: 36px !important;
          }
          .blog-img-container {
            aspect-ratio: 16 / 10 !important;
          }
        }
      `}),(0,t.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:[(0,t.jsxs)("div",{style:{marginBottom:"40px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"12px",marginBottom:"10px"},children:[(0,t.jsx)("span",{style:{width:"46px",height:"1.5px",background:"#222222",display:"inline-block"}}),(0,t.jsx)("span",{style:{fontSize:"11px",letterSpacing:"1.8px",textTransform:"uppercase",color:"#222222",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:600},children:"LATEST NEWS"})]}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(32px, 4.5vw, 50px)",fontWeight:700,fontFamily:"'Playfair Display', Georgia, serif",color:"#111111",lineHeight:1.15,letterSpacing:"-0.5px"},children:"Explore all our blogs"})]}),(0,t.jsx)("div",{className:"blogs-grid",children:a.map(e=>(0,t.jsxs)(n.default,{href:e.href,className:"blog-item",children:[(0,t.jsx)("div",{className:"blog-img-container",children:(0,t.jsx)(i.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover"},sizes:"(max-width: 900px) 100vw, 33vw"})}),(0,t.jsxs)("div",{style:{fontSize:"12.5px",color:"#666666",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:500,display:"flex",alignItems:"center",gap:"6px"},children:[(0,t.jsx)("span",{children:e.date}),(0,t.jsx)("span",{children:"•"}),(0,t.jsx)("span",{children:e.categories})]}),(0,t.jsx)("h3",{className:"blog-title",children:e.title})]},e.id))})]})]})}])},89800,e=>{"use strict";var t=e.i(43476),i=e.i(71645),n=e.i(25164),a=e.i(22016),r=e.i(21551);let o=[{img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Diamond ring",items:"7 Items",href:"/diamonds",textDark:!1},{img:"/wp-content/uploads/shop page/banner-02.jpg",title:"Diamond bracelets",items:"3 Items",href:"/diamonds",textDark:!0},{img:"/wp-content/uploads/shop page/bannerr-03.jpg",title:"Necklace sets",items:"3 Items",href:"/diamonds",textDark:!1},{img:"/wp-content/uploads/shop page/banner-04.jpg",title:"Earrings",items:"5 Items",href:"/diamonds/white",textDark:!1}];e.s(["default",0,function(){let[e,s]=(0,i.useState)(o);return(0,i.useEffect)(()=>{!async function(){try{let e=await (0,r.getCategories)();if(e&&e.length>0){let t=e.filter(e=>!1!==e.published);if(t.length>0){let e=t.map(e=>({img:e.image||"/wp-content/uploads/shop page/banner-01.jpg",title:e.name,items:e.itemsCountText||"5 Items",href:"/diamonds",textDark:!!e.textDark}));s(e)}}}catch(e){console.error("Categories fallback to default:",e)}}()},[]),(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"28px 24px 56px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .cat-grid {
          display: flex;
          gap: 12px;
          max-width: 1200px;
          margin: 0 auto;
          align-items: stretch;
        }

        .cat-item {
          position: relative;
          border-radius: 16px;
          overflow: hidden;
          flex: 1;
          height: 280px;
          display: block;
          text-decoration: none;
          cursor: pointer;
          transition: transform 0.3s, box-shadow 0.3s;
        }
        .cat-item:hover {
          transform: translateY(-5px);
          box-shadow: 0 16px 40px rgba(0,0,0,0.18);
        }

        /* text label sits top-left */
        .cat-text {
          position: absolute;
          top: 16px;
          left: 18px;
          z-index: 3;
        }
        .cat-text-title {
          display: block;
          font-size: 15px;
          font-weight: 700;
          font-family: var(--title-fonts, 'Readex Pro', sans-serif);
          line-height: 1.25;
          margin-bottom: 5px;
        }
        .cat-text-count {
          display: block;
          font-size: 12px;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
        }

        @media (max-width: 680px) {
          .cat-grid { flex-wrap: wrap; }
          .cat-item { flex: none; width: calc(50% - 6px); height: 200px; }
        }
        @media (max-width: 400px) {
          .cat-item { width: 100%; height: 220px; }
        }
      `}),(0,t.jsx)("div",{className:"cat-grid",children:e.map(e=>{let i=e.textDark?"#111111":"#ffffff",r=e.textDark?"linear-gradient(160deg, rgba(255,255,255,0.45) 0%, transparent 50%)":"linear-gradient(160deg, rgba(0,0,0,0.38) 0%, transparent 55%)";return(0,t.jsxs)(a.default,{href:e.href,className:"cat-item",children:[(0,t.jsx)(n.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover",objectPosition:"center"},sizes:"(max-width: 680px) 45vw, 25vw"}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:r}}),(0,t.jsxs)("div",{className:"cat-text",children:[(0,t.jsx)("span",{className:"cat-text-title",style:{color:i},children:e.title}),(0,t.jsx)("span",{className:"cat-text-count",style:{color:i,opacity:.82},children:e.items})]})]},e.title)})})]})}])},95953,e=>{"use strict";var t=e.i(43476),i=e.i(25164),n=e.i(22016);e.s(["default",0,function(){return(0,t.jsxs)("section",{style:{position:"relative",width:"100%",minHeight:"88vh",background:"#080808",display:"flex",alignItems:"center",overflow:"hidden",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .hero-shine-btn {
          display: inline-block;
          padding: 12px 32px;
          background: transparent;
          border: 1.5px solid rgba(255,255,255,0.5);
          color: #ffffff;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
          font-size: 12px;
          letter-spacing: 3px;
          text-transform: uppercase;
          text-decoration: none;
          transition: background 0.3s, border-color 0.3s;
          cursor: pointer;
        }
        .hero-shine-btn:hover {
          background: rgba(255,255,255,0.12);
          border-color: #ffffff;
        }
        .hero-shine-word {
          font-family: 'Playfair Display', Georgia, serif;
          font-size: clamp(40px, 6.5vw, 92px);
          font-weight: 700;
          line-height: 0.9;
          color: #ffffff;
          letter-spacing: -2px;
          text-transform: uppercase;
        }
        @media (max-width: 900px) {
          .hero-inner { flex-direction: column !important; padding-top: 120px !important; }
          .hero-left-text  { align-items: center !important; text-align: center !important; }
          .hero-right-text { align-items: center !important; text-align: center !important; }
          .hero-img-col { width: 70vw !important; height: 260px !important; }
        }
        @media (max-width: 540px) {
          .hero-img-col { width: 90vw !important; height: 200px !important; }
        }
      `}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to right, #080808 0%, transparent 18%, transparent 82%, #080808 100%)",zIndex:1,pointerEvents:"none"}}),(0,t.jsx)("div",{style:{position:"absolute",inset:0,background:"linear-gradient(to bottom, #080808 0%, transparent 15%, transparent 85%, #080808 100%)",zIndex:1,pointerEvents:"none"}}),(0,t.jsxs)("div",{className:"hero-inner",style:{position:"relative",zIndex:2,width:"100%",maxWidth:"1280px",margin:"0 auto",padding:"120px 40px 90px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:"32px",boxSizing:"border-box"},children:[(0,t.jsxs)("div",{className:"hero-left-text",style:{display:"flex",flexDirection:"column",alignItems:"flex-start",gap:"18px",flex:"1",minWidth:0},children:[(0,t.jsx)("span",{className:"hero-shine-word",children:"SHINE"}),(0,t.jsx)("span",{className:"hero-shine-word",children:"BRIGHT"}),(0,t.jsx)("p",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px",lineHeight:1.8,maxWidth:"210px",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',margin:"6px 0"},children:"Lab-grown diamonds in extraordinary colour. Discover our signature pink and white collection."}),(0,t.jsx)(n.default,{href:"/diamonds/pink",className:"hero-shine-btn",children:"EXPLORE"})]}),(0,t.jsx)("div",{className:"hero-img-col",style:{position:"relative",width:"38%",height:"340px",flexShrink:0},children:(0,t.jsx)(i.default,{src:"/wp-content/uploads/shop page/header picture.png",alt:"Brilliant cut diamond",fill:!0,priority:!0,style:{objectFit:"contain",objectPosition:"center"},sizes:"(max-width: 900px) 70vw, 38vw"})}),(0,t.jsxs)("div",{className:"hero-right-text",style:{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:"18px",flex:"1",minWidth:0},children:[(0,t.jsx)("span",{className:"hero-shine-word",style:{textAlign:"right"},children:"DAY AND"}),(0,t.jsx)("span",{className:"hero-shine-word",style:{textAlign:"right"},children:"NIGHT"}),(0,t.jsx)("p",{style:{color:"rgba(255,255,255,0.6)",fontSize:"13px",lineHeight:1.8,maxWidth:"210px",textAlign:"right",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',margin:"6px 0"},children:"Lab-grown diamonds. No diamond mining. Crafted for every moment."})]})]})]})}])},87711,e=>{"use strict";var t=e.i(43476),i=e.i(71645),n=e.i(25164),a=e.i(22016),r=e.i(21551);let o=["All","Rings","Earrings","Diamonds","Necklaces","Bracelets"],s=[{id:1,img:"/wp-content/uploads/shop page/pro-21-300x300.png",title:"Pink Morganite Butterfly Ring",price:"$4,200",originalPrice:"$5,190",discount:"-19%",rating:4.8,tab:"Rings"},{id:2,img:"/wp-content/uploads/shop page/pro-03-300x300.jpg",title:"Fancy Pink Drop Earrings",price:"$2,100",originalPrice:"$2,599",discount:"-19%",rating:4.6,tab:"Earrings"},{id:3,img:"/wp-content/uploads/shop page/pro-05-300x300.jpg",title:"Teal Drop Ring & Earring Set",price:"$3,600",originalPrice:null,discount:null,rating:4.9,tab:"Rings"},{id:4,img:"/wp-content/uploads/shop page/pro-04-300x300.jpg",title:"Pink Cluster Necklace",price:"$600",originalPrice:null,discount:null,rating:4.5,tab:"Necklaces"},{id:5,img:"/wp-content/uploads/shop page/pro-07-300x300.jpg",title:"Emerald Serpentine Ring",price:"$4,800",originalPrice:null,discount:null,rating:5,tab:"Rings"},{id:6,img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Emerald Eternity Band",price:"$2,800",originalPrice:null,discount:null,rating:4.7,tab:"Rings"}];function l({rating:e}){return(0,t.jsxs)("span",{style:{color:"#BFA37C",fontSize:"12px"},children:["★".repeat(Math.floor(e)),"☆".repeat(5-Math.floor(e)),(0,t.jsxs)("span",{style:{color:"#888",marginLeft:"4px",fontSize:"11px"},children:["(",e,")"]})]})}e.s(["default",0,function(){let[e,d]=(0,i.useState)("All"),[p,c]=(0,i.useState)(s);(0,i.useEffect)(()=>{!async function(){try{let e=await (0,r.getProducts)({publishedOnly:!0});if(e&&e.length>0){let t=e.filter(e=>!1!==e.isNewArrival).map(e=>{let t=e.salePrice?`$${e.salePrice.toLocaleString()}`:null,i=e.salePrice&&e.price<e.salePrice?`-${Math.round((e.salePrice-e.price)/e.salePrice*100)}%`:null;return{id:e.id,img:e.images?.[0]?.url||"/wp-content/uploads/shop page/pro-21-300x300.png",title:e.name,price:`$${(e.price||0).toLocaleString()}`,originalPrice:t,discount:i,rating:e.rating||5,tab:e.category||"Rings"}});t.length>0&&c(t)}}catch(e){console.error("Using default products fallback:",e)}}()},[]);let g="All"===e?p:p.filter(t=>t.tab===e);return(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"70px 0 80px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .arrivals-tab {
          background: transparent;
          border: none;
          font-family: var(--body-fonts, 'Nunito Sans', sans-serif);
          font-size: 13px;
          cursor: pointer;
          padding: 6px 0;
          position: relative;
          transition: color 0.2s;
          white-space: nowrap;
        }
        .arrivals-tab.active { color: #111 !important; }
        .arrivals-tab.active::after {
          content: '';
          position: absolute;
          bottom: 0; left: 0; right: 0;
          height: 2px;
          background: #111;
        }
        .product-card {
          background: #ffffff;
          border-radius: 12px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          transition: box-shadow 0.2s;
        }
        .product-card:hover { box-shadow: 0 8px 32px rgba(0,0,0,0.12); }
        .product-card-img-wrap {
          position: relative;
          width: 100%;
          aspect-ratio: 1 / 1;
          overflow: hidden;
        }
        .arrivals-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }
        @media (max-width: 900px) {
          .arrivals-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (max-width: 540px) {
          .arrivals-grid { grid-template-columns: 1fr !important; }
        }
      `}),(0,t.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto",padding:"0 24px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"flex-end",justifyContent:"space-between",flexWrap:"wrap",gap:"16px",marginBottom:"36px"},children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{style:{margin:"0 0 8px",fontSize:"11px",letterSpacing:"2px",textTransform:"uppercase",color:"#BFA37C",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:"— EXPLORE NOW"}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts,"Readex Pro",sans-serif)',color:"#111",lineHeight:1.1},children:"New Arrivals"})]}),(0,t.jsx)("div",{style:{display:"flex",gap:"24px",overflowX:"auto",paddingBottom:"4px"},children:o.map(i=>(0,t.jsx)("button",{className:`arrivals-tab${e===i?" active":""}`,style:{color:e===i?"#111":"#888"},onClick:()=>d(i),children:i},i))})]}),(0,t.jsx)("div",{className:"arrivals-grid",children:g.map(e=>(0,t.jsx)(a.default,{href:"/diamonds",style:{textDecoration:"none",color:"inherit"},children:(0,t.jsxs)("div",{className:"product-card",children:[(0,t.jsxs)("div",{className:"product-card-img-wrap",children:[(0,t.jsx)(n.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover",transition:"transform 0.4s"},sizes:"(max-width: 540px) 90vw, (max-width: 900px) 45vw, 30vw",onMouseEnter:e=>{e.currentTarget.style.transform="scale(1.05)"},onMouseLeave:e=>{e.currentTarget.style.transform="scale(1)"}}),e.discount&&(0,t.jsx)("span",{style:{position:"absolute",top:"12px",left:"12px",background:"#ff5722",color:"#fff",fontSize:"11px",fontWeight:700,padding:"3px 8px",borderRadius:"4px",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:e.discount})]}),(0,t.jsxs)("div",{style:{padding:"16px"},children:[(0,t.jsx)(l,{rating:e.rating}),(0,t.jsx)("h4",{style:{margin:"8px 0 6px",fontSize:"14px",fontWeight:600,color:"#111",fontFamily:'var(--title-fonts,"Readex Pro",sans-serif)',lineHeight:1.3},children:e.title}),(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"8px"},children:[(0,t.jsx)("span",{style:{fontSize:"15px",fontWeight:700,color:"#111"},children:e.price}),e.originalPrice&&(0,t.jsx)("span",{style:{fontSize:"13px",color:"#aaa",textDecoration:"line-through"},children:e.originalPrice})]})]})]})},e.id))}),(0,t.jsx)("div",{style:{textAlign:"center",marginTop:"48px"},children:(0,t.jsx)(a.default,{href:"/diamonds",style:{display:"inline-block",padding:"14px 40px",background:"#111111",color:"#fff",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)',fontSize:"12px",letterSpacing:"2px",textTransform:"uppercase",textDecoration:"none",borderRadius:"4px",transition:"background 0.2s"},children:"LOAD MORE PRODUCTS"})})]})]})}])},50070,e=>{"use strict";var t=e.i(43476),i=e.i(71645),n=e.i(25164),a=e.i(22016),r=e.i(21551);let o=[{img:"/wp-content/uploads/shop page/category-01.png",title:"Round Brilliant",href:"/diamonds/white"},{img:"/wp-content/uploads/shop page/category-02.png",title:"Triangle Cut",href:"/diamonds/white"},{img:"/wp-content/uploads/shop page/category-03.png",title:"Pink Diamonds",href:"/diamonds/pink"},{img:"/wp-content/uploads/shop page/category-04.png",title:"Emerald Cut",href:"/diamonds/white"}];e.s(["default",0,function(){let[e,s]=(0,i.useState)(o);return(0,i.useEffect)(()=>{!async function(){try{let e=await (0,r.getCategories)();if(e&&e.length>0){let t=e.filter(e=>e.subcategories&&e.subcategories.includes("Shapes"));t.length>=4&&s(t.map(e=>({img:e.image||"/wp-content/uploads/shop page/category-01.png",title:e.name,href:"pink-diamonds"===e.slug?"/diamonds/pink":"/diamonds/white"})))}}catch(e){}}()},[]),(0,t.jsxs)("section",{style:{background:"#f5f1ec",padding:"70px 24px",boxSizing:"border-box"},children:[(0,t.jsx)("style",{children:`
        .diamond-shape-card {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 16px;
          text-decoration: none;
          color: inherit;
          flex: 1;
          min-width: 160px;
        }
        .diamond-shape-img {
          position: relative;
          width: 180px;
          height: 180px;
          border-radius: 50%;
          overflow: hidden;
          transition: transform 0.3s, box-shadow 0.3s;
        }
        .diamond-shape-card:hover .diamond-shape-img {
          transform: translateY(-6px);
          box-shadow: 0 16px 40px rgba(0,0,0,0.18);
        }
        .diamond-shape-name {
          font-family: var(--title-fonts, 'Readex Pro', sans-serif);
          font-size: 15px;
          font-weight: 600;
          color: #111;
          text-align: center;
        }
        @media (max-width: 640px) {
          .diamonds-row { flex-wrap: wrap !important; }
          .diamond-shape-card { min-width: calc(50% - 16px) !important; }
          .diamond-shape-img { width: 130px !important; height: 130px !important; }
        }
      `}),(0,t.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:[(0,t.jsxs)("div",{style:{marginBottom:"48px"},children:[(0,t.jsx)("p",{style:{margin:"0 0 8px",fontSize:"11px",letterSpacing:"2px",textTransform:"uppercase",color:"#BFA37C",fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:"— OUR COLLECTION"}),(0,t.jsx)("h2",{style:{margin:"0 0 12px",fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts,"Readex Pro",sans-serif)',color:"#111",lineHeight:1.1},children:"Shop by Shape and Carat"}),(0,t.jsx)("p",{style:{margin:0,fontSize:"15px",color:"#666",maxWidth:"600px",lineHeight:1.6,fontFamily:'var(--body-fonts,"Nunito Sans",sans-serif)'},children:"Every diamond has its own character. Explore our collection by shape and carat weight to discover a stone that reflects your personal style."})]}),(0,t.jsx)("div",{className:"diamonds-row",style:{display:"flex",gap:"32px",justifyContent:"center",flexWrap:"nowrap"},children:e.map(e=>(0,t.jsxs)(a.default,{href:e.href,className:"diamond-shape-card",children:[(0,t.jsx)("div",{className:"diamond-shape-img",children:(0,t.jsx)(n.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover"},sizes:"180px"})}),(0,t.jsx)("span",{className:"diamond-shape-name",children:e.title})]},e.title))})]})]})}])},20184,e=>{"use strict";var t=e.i(43476),i=e.i(71645),n=e.i(25164),a=e.i(22016),r=e.i(21551);let o=[{id:1,img:"/wp-content/uploads/shop page/pro-21-300x300.png",title:"Pink Morganite Butterfly Ring",price:"From $4,200",badge:"NEW",rating:4.9},{id:2,img:"/wp-content/uploads/shop page/pro-03-300x300.jpg",title:"Purple Diamond Hoop Earrings",price:"From $2,100",badge:"HOT",rating:4.8},{id:3,img:"/wp-content/uploads/shop page/pro-05-300x300.jpg",title:"Teal Drop Halo Ring",price:"From $77.00",badge:"NEW",rating:5},{id:4,img:"/wp-content/uploads/shop page/pro-04-300x300.jpg",title:"Pink Cluster Necklace",price:"From $600",badge:null,rating:4.7},{id:5,img:"/wp-content/uploads/shop page/banner-02.jpg",title:"Diamond Pavé Band",price:"From $900",badge:null,rating:4.9},{id:6,img:"/wp-content/uploads/shop page/pro-07-300x300.jpg",title:"Emerald Serpentine Ring",price:"From $1,742",badge:"TRENDING",rating:5},{id:7,img:"/wp-content/uploads/shop page/banner-01.jpg",title:"Emerald Eternity Band",price:"From $2,800",badge:null,rating:4.8},{id:8,img:"/wp-content/uploads/shop page/banner-04.jpg",title:"Rainbow Gemstone Huggies",price:"From $1,250",badge:"BESTSELLER",rating:4.9},{id:9,img:"/wp-content/uploads/shop page/bannerr-03.jpg",title:"Sapphire Collar Necklace Set",price:"From $3,400",badge:null,rating:5}];e.s(["default",0,function(){let[e,s]=(0,i.useState)(o),l="#BFA37C";(0,i.useEffect)(()=>{!async function(){try{let e=await (0,r.getProducts)({publishedOnly:!0});if(e&&e.length>0){let t=e.filter(e=>e.isTrending||e.isFeatured),i=(t.length>0?t:e).map(e=>({id:e.id,img:e.images?.[0]?.url||"/wp-content/uploads/shop page/pro-21-300x300.png",title:e.name,price:`From $${(e.price||0).toLocaleString()}`,badge:e.badge||(e.isNewArrival?"NEW":null),rating:e.rating||5}));i.length>0&&s(i)}}catch(e){console.error("Trending products fallback to default:",e)}}()},[]);let d=[...e,...e];return(0,t.jsxs)("section",{style:{background:"#ffffff",padding:"70px 0 80px",boxSizing:"border-box",overflow:"hidden",position:"relative"},children:[(0,t.jsx)("style",{children:`
        @keyframes marqueeInfinite {
          0% {
            transform: translate3d(0, 0, 0);
          }
          100% {
            transform: translate3d(-50%, 0, 0);
          }
        }

        .infinite-marquee-container {
          position: relative;
          width: 100%;
          overflow: hidden;
          padding: 10px 0 20px;
        }

        .infinite-marquee-track {
          display: flex;
          gap: 22px;
          width: max-content;
          animation: marqueeInfinite 38s linear infinite;
          will-change: transform;
        }

        .infinite-marquee-container:hover .infinite-marquee-track {
          animation-play-state: paused;
        }

        .trending-card {
          flex: 0 0 250px;
          width: 250px;
          background: #ffffff;
          border-radius: 14px;
          overflow: hidden;
          text-decoration: none;
          color: inherit;
          display: flex;
          flex-direction: column;
          box-shadow: 0 4px 18px rgba(0, 0, 0, 0.05);
          transition: transform 0.3s cubic-bezier(0.2, 0, 0, 1), box-shadow 0.3s ease;
          border: 1px solid rgba(0, 0, 0, 0.05);
        }

        .trending-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 14px 34px rgba(0, 0, 0, 0.12);
        }

        .trending-card-img-wrap {
          position: relative;
          width: 100%;
          aspect-ratio: 1 / 1;
          background: #faf8f5;
          overflow: hidden;
        }

        .trending-card-img-wrap img {
          transition: transform 0.45s ease;
        }

        .trending-card:hover .trending-card-img-wrap img {
          transform: scale(1.08);
        }

        .edge-fade-left {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          width: 80px;
          background: linear-gradient(to right, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
          z-index: 5;
          pointer-events: none;
        }

        .edge-fade-right {
          position: absolute;
          top: 0;
          bottom: 0;
          right: 0;
          width: 80px;
          background: linear-gradient(to left, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
          z-index: 5;
          pointer-events: none;
        }

        @media (max-width: 600px) {
          .trending-card {
            flex: 0 0 200px;
            width: 200px;
          }
          .edge-fade-left, .edge-fade-right {
            width: 30px;
          }
        }
      `}),(0,t.jsx)("div",{style:{maxWidth:"1200px",margin:"0 auto",padding:"0 24px 36px"},children:(0,t.jsxs)("div",{style:{display:"flex",alignItems:"flex-end",justifyContent:"space-between",flexWrap:"wrap",gap:"12px"},children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("p",{style:{margin:"0 0 8px",fontSize:"11px",letterSpacing:"2px",textTransform:"uppercase",color:l,fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',fontWeight:600},children:"— TRENDING NOW"}),(0,t.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#111111",lineHeight:1.1},children:"Featured Products"})]}),(0,t.jsx)(a.default,{href:"/diamonds",style:{fontSize:"13px",fontWeight:600,color:"#111111",textDecoration:"none",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',display:"inline-flex",alignItems:"center",gap:"6px",borderBottom:"1px solid #111111",paddingBottom:"2px"},children:"View all →"})]})}),(0,t.jsxs)("div",{className:"infinite-marquee-container",children:[(0,t.jsx)("div",{className:"edge-fade-left"}),(0,t.jsx)("div",{className:"edge-fade-right"}),(0,t.jsx)("div",{className:"infinite-marquee-track",children:d.map((e,i)=>(0,t.jsxs)(a.default,{href:"/diamonds",className:"trending-card",children:[(0,t.jsxs)("div",{className:"trending-card-img-wrap",children:[(0,t.jsx)(n.default,{src:e.img,alt:e.title,fill:!0,style:{objectFit:"cover"},sizes:"250px"}),e.badge&&(0,t.jsx)("span",{style:{position:"absolute",top:"12px",left:"12px",background:"HOT"===e.badge?"#e53935":"BESTSELLER"===e.badge?"#111111":"#ff5722",color:"#ffffff",fontSize:"10px",fontWeight:800,letterSpacing:"0.5px",padding:"3px 8px",borderRadius:"4px",textTransform:"uppercase",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',zIndex:2},children:e.badge})]}),(0,t.jsxs)("div",{style:{padding:"16px"},children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:"4px",marginBottom:"6px"},children:[(0,t.jsx)("span",{style:{color:l,fontSize:"11px"},children:"★"}),(0,t.jsx)("span",{style:{fontSize:"11px",color:"#777777",fontWeight:600,fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)'},children:e.rating})]}),(0,t.jsx)("h4",{style:{margin:"0 0 6px",fontSize:"14px",fontWeight:600,color:"#111111",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',lineHeight:1.35,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},title:e.title,children:e.title}),(0,t.jsx)("p",{style:{margin:0,fontSize:"13px",fontWeight:700,color:"#222222",fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)'},children:e.price})]})]},`${e.id}-${i}`))})]})]})}])},2187,e=>{e.v(e=>Promise.resolve().then(()=>e(21551)))},43414,e=>{e.v(e=>Promise.resolve().then(()=>e(60664)))},27510,e=>{e.v(t=>Promise.all(["static/chunks/3sbmzr8x4wmgj.js"].map(t=>e.l(t))).then(()=>t(48323)))}]);