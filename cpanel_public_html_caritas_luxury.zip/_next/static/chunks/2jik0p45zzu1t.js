(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,15430,e=>{"use strict";var i=e.i(43476),t=e.i(71645),a=e.i(25164),n=e.i(22016);let r=[{year:"2018",label:"Recognition",subtitle:"01 / HISTORIC LANDMARK",title:"Official Recognition as Genuine Diamonds",description:"In 2018, the US Federal Trade Commission (FTC) officially updated its jewellery standards to recognize lab-grown diamonds as real diamonds, acknowledging they possess the exact same crystalline carbon structure, optical properties, and physical hardness as mined stones.",img:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond 3.webp"},{year:"2020",label:"Plasma Synthesis",subtitle:"02 / ADVANCED CVD & HPHT",title:"Breakthrough in Plasma Synthesis & Type IIa Purity",description:"Pioneering plasma reactors and high-pressure chambers achieved unprecedented atomic synthesis. By replicating Earth’s mantle pressure and 1,000°C+ thermal energy in clean laboratory environments, synthesis unlocked Type IIa chemical purity — a level reached by only 1–2% of natural diamonds.",img:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond.webp"},{year:"2022",label:"Fancy Diamonds",subtitle:"03 / FANCY COLORS & CARAT FREEDOM",title:"Mastering Rare Pink Diamonds & Large Carat Scaling",description:"Scientific mastery over atomic lattice growth unlocked the creation of rare fancy pink, canary yellow, and blue diamonds alongside flawless multi-carat solitaires — creating extraordinary collector gems grown in controlled laboratory environments.",img:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond 4.jpg"},{year:"2024",label:"Master Cut",subtitle:"04 / ARTISAN POLISHING & 3D LASER",title:"Precision 3D Laser Cutting & Master Faceting",description:"Every rough diamond is scanned using state-of-the-art 3D tomography to calculate the optimal cut geometry. Skilled diamond artisans then cut and hand-polish each facet to exact mathematical angles, unlocking maximum light reflection, optical fire, and scintillation.",img:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond 2.webp"},{year:"Present",label:"Certified Luxury",subtitle:"05 / INDEPENDENT GEMOLOGICAL CERTIFICATION",title:"Independently Certified by IGI and GIA",description:"Today, lab-grown diamonds represent a modern approach to timeless luxury. Grown in laboratories without diamond mining, each stone provides uncompromising quality, brilliance, and enduring beauty.",img:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond 3.webp"}],o=[{number:"01",title:"Exceptional Beauty",description:"Enjoy the timeless brilliance, fire, and sparkle of genuine diamonds. Lab-grown diamonds offer the same optical beauty and refraction as their mined counterparts."},{number:"02",title:"Outstanding Quality",description:"With a hardness of 10 on the Mohs scale, lab-grown diamonds offer supreme durability and scratch-resistance for everyday fine jewellery and heirloom milestones."},{number:"03",title:"More Accessible Luxury",description:"Lab-grown diamonds generally cost less than comparable mined diamonds, allowing you to explore larger stones and beautiful custom settings within your budget."},{number:"04",title:"Modern Innovation",description:"Created through pioneering clean technology, every lab-grown diamond represents the remarkable combination of advanced science, precision engineering, and master craftsmanship."},{number:"05",title:"A Thoughtful Alternative",description:"Our diamonds are grown in laboratories, avoiding the need to excavate a diamond mine. Bypassing diamond extraction avoids the direct land disturbance associated with traditional mining."},{number:"06",title:"Endless Possibilities",description:"From classic solitaires and pink diamond pavé to contemporary statement pieces, lab-grown diamonds give you complete freedom to express your personal style."}],s=[{feature:"Origin",lab:"Created in high-tech laboratories",natural:"Formed naturally underground"},{feature:"Composition",lab:"Pure crystalline carbon (C)",natural:"Pure crystalline carbon (C)"},{feature:"Hardness",lab:"10 on the Mohs scale",natural:"10 on the Mohs scale"},{feature:"Brilliance & Fire",lab:"Same refractive index (2.42)",natural:"Same refractive index (2.42)"},{feature:"Formation Time",lab:"Weeks to months",natural:"Billions of years"},{feature:"Value & Price",lab:"Generally 50–70% more affordable",natural:"Generally more expensive"}];e.s(["default",0,function(){let[e,l]=(0,t.useState)(3),d=r[e],c="var(--primary-color, #BFA37C)";return(0,i.jsxs)("div",{style:{fontFamily:'var(--body-fonts, "Nunito Sans", sans-serif)',color:"#333333"},children:[(0,i.jsx)("style",{children:`
        /* Checklist items */
        .wlg-check-item {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 14px;
          font-size: 14.5px;
          line-height: 1.6;
          color: #444444;
        }
        .wlg-check-icon {
          color: var(--primary-color, #BFA37C);
          font-weight: 800;
          font-size: 16px;
          line-height: 1.4;
          flex-shrink: 0;
        }

        /* Stats block */
        .wlg-stat-col {
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .wlg-stat-label {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 1.5px;
          text-transform: uppercase;
          color: var(--primary-color, #BFA37C);
        }
        .wlg-stat-val {
          font-size: 40px;
          font-weight: 800;
          font-family: var(--title-fonts, "Readex Pro", sans-serif);
          color: #111111;
          line-height: 1;
        }

        /* Interactive Timeline line */
        .timeline-track-wrap {
          position: relative;
          padding: 30px 10px;
          margin-bottom: 36px;
        }
        .timeline-track-line {
          position: absolute;
          top: 50%;
          left: 4%;
          right: 4%;
          height: 2px;
          background: #d8d2c9;
          transform: translateY(-50%);
          z-index: 1;
        }
        .timeline-points-row {
          position: relative;
          z-index: 2;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .timeline-point-btn {
          background: none;
          border: none;
          cursor: pointer;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 4px;
          transition: transform 0.2s ease;
        }
        .timeline-point-btn:hover {
          transform: translateY(-2px);
        }
        .timeline-point-year {
          font-size: 13px;
          font-weight: 700;
          font-family: var(--title-fonts, "Readex Pro", sans-serif);
          color: #111111;
          transition: color 0.2s ease;
        }
        .timeline-point-dot {
          width: 14px;
          height: 14px;
          border-radius: 50%;
          background: #111111;
          border: 3px solid #ffffff;
          box-shadow: 0 0 0 1px #d8d2c9;
          transition: all 0.2s ease;
        }
        .timeline-point-btn.active .timeline-point-year {
          color: var(--primary-color, #BFA37C);
        }
        .timeline-point-btn.active .timeline-point-dot {
          background: var(--primary-color, #BFA37C);
          width: 18px;
          height: 18px;
          box-shadow: 0 0 0 3px rgba(191, 163, 124, 0.28);
        }

        /* Arrows */
        .timeline-nav-btn {
          width: 38px;
          height: 38px;
          border-radius: 50%;
          border: none;
          background: #BFA37C;
          color: #ffffff;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          font-size: 15px;
          font-weight: 700;
          transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .timeline-nav-btn:hover {
          opacity: 0.9;
          transform: scale(1.05);
        }

        /* 6 Reason Cards */
        .reason-card {
          background: #ffffff;
          border-radius: 16px;
          padding: 36px 30px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.04);
          border: 1px solid rgba(0, 0, 0, 0.05);
          display: flex;
          flex-direction: column;
          gap: 12px;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .reason-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 14px 34px rgba(0, 0, 0, 0.09);
        }
        .reason-num {
          font-size: 14px;
          font-weight: 800;
          color: var(--primary-color, #BFA37C);
          letter-spacing: 1.5px;
          font-family: var(--title-fonts, "Readex Pro", sans-serif);
        }
        .reason-title {
          margin: 0;
          font-size: 19px;
          font-weight: 700;
          color: #111111;
          font-family: var(--title-fonts, "Readex Pro", sans-serif);
        }
        .reason-desc {
          margin: 0;
          font-size: 14px;
          line-height: 1.7;
          color: #666666;
        }

        /* Comparison Table */
        .comp-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          border-radius: 16px;
          overflow: hidden;
          background: #ffffff;
          box-shadow: 0 4px 24px rgba(0, 0, 0, 0.05);
          border: 1px solid rgba(0, 0, 0, 0.06);
        }
        .comp-table th {
          background: #111111;
          color: #ffffff;
          padding: 18px 24px;
          font-size: 14px;
          font-weight: 700;
          letter-spacing: 1px;
          text-transform: uppercase;
          font-family: var(--title-fonts, "Readex Pro", sans-serif);
          text-align: left;
        }
        .comp-table th:first-child {
          background: #1e1e1e;
        }
        .comp-table td {
          padding: 18px 24px;
          font-size: 14.5px;
          border-bottom: 1px solid #f0ede8;
          color: #444444;
        }
        .comp-table tr:last-child td {
          border-bottom: none;
        }
        .comp-table tr:nth-child(even) td {
          background: #faf8f5;
        }
        .comp-table td strong {
          color: #111111;
        }

        @media (max-width: 900px) {
          .wlg-split-row {
            flex-direction: column !important;
          }
          .wlg-images-grid {
            width: 100% !important;
          }
          .timeline-card-split {
            flex-direction: column !important;
          }
          .reasons-grid-3col {
            grid-template-columns: 1fr !important;
          }
        }
      `}),(0,i.jsx)("section",{style:{backgroundColor:"#ffffff",padding:"90px 24px 100px"},children:(0,i.jsx)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:(0,i.jsxs)("div",{className:"wlg-split-row",style:{display:"flex",gap:"50px",alignItems:"center"},children:[(0,i.jsxs)("div",{style:{flex:"1.1",minWidth:0},children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase",color:c,marginBottom:"10px"},children:"ABOUT LAB GROWN"}),(0,i.jsx)("h2",{style:{margin:"0 0 20px",fontSize:"clamp(32px, 3.8vw, 46px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315",lineHeight:1.2},children:"The Beauty of Diamonds, Redefined"}),(0,i.jsxs)("p",{style:{fontSize:"15.5px",lineHeight:1.75,color:"#555555",margin:"0 0 16px"},children:["At ",(0,i.jsx)("strong",{style:{color:"#111111"},children:"Caritas Luxury"}),", we believe that true luxury is about more than brilliance — it’s about making thoughtful choices without compromising on beauty, quality, or elegance."]}),(0,i.jsx)("p",{style:{fontSize:"15px",lineHeight:1.75,color:"#666666",margin:"0 0 28px"},children:"Lab-grown diamonds offer the same captivating sparkle, exceptional hardness, and chemical and optical properties as mined diamonds. Created using advanced technology that replicates the natural diamond-growing process, they represent a modern approach to timeless luxury. Discover a diamond that reflects your style, your values, and your individuality."}),(0,i.jsxs)("div",{style:{marginBottom:"36px"},children:[(0,i.jsxs)("div",{className:"wlg-check-item",children:[(0,i.jsx)("span",{className:"wlg-check-icon",children:"✓"}),(0,i.jsx)("span",{children:"100% genuine carbon diamond, chemically & optically identical to mined diamonds."})]}),(0,i.jsxs)("div",{className:"wlg-check-item",children:[(0,i.jsx)("span",{className:"wlg-check-icon",children:"✓"}),(0,i.jsx)("span",{children:"Same refractive brilliance, fire, and hardness (10 on the Mohs scale)."})]}),(0,i.jsxs)("div",{className:"wlg-check-item",children:[(0,i.jsx)("span",{className:"wlg-check-icon",children:"✓"}),(0,i.jsx)("span",{children:"Grown in controlled laboratory environments — no diamond mining."})]}),(0,i.jsxs)("div",{className:"wlg-check-item",children:[(0,i.jsx)("span",{className:"wlg-check-icon",children:"✓"}),(0,i.jsx)("span",{children:"Independently certified by world-leading gem labs including IGI & GIA."})]})]}),(0,i.jsxs)("div",{style:{display:"flex",gap:"48px",paddingTop:"10px",borderTop:"1px solid #f0ede8"},children:[(0,i.jsxs)("div",{className:"wlg-stat-col",children:[(0,i.jsx)("span",{className:"wlg-stat-label",children:"01. MOHS HARDNESS"}),(0,i.jsx)("span",{className:"wlg-stat-val",children:"10 / 10"})]}),(0,i.jsxs)("div",{className:"wlg-stat-col",children:[(0,i.jsx)("span",{className:"wlg-stat-label",children:"02. CARBON PURITY"}),(0,i.jsx)("span",{className:"wlg-stat-val",children:"100%"})]}),(0,i.jsxs)("div",{className:"wlg-stat-col",children:[(0,i.jsx)("span",{className:"wlg-stat-label",children:"03. ETHICAL ORIGIN"}),(0,i.jsx)("span",{className:"wlg-stat-val",children:"100%"})]})]})]}),(0,i.jsxs)("div",{className:"wlg-images-grid",style:{flex:"0.9",display:"flex",gap:"16px",height:"480px"},children:[(0,i.jsx)("div",{style:{position:"relative",flex:1,height:"100%",borderRadius:"24px",overflow:"hidden",boxShadow:"0 12px 36px rgba(0,0,0,0.08)"},children:(0,i.jsx)(a.default,{src:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond.webp",alt:"Diamond cutting and lapidary polishing machine",fill:!0,style:{objectFit:"cover"},sizes:"(max-width: 900px) 50vw, 25vw"})}),(0,i.jsx)("div",{style:{position:"relative",flex:1,height:"100%",borderRadius:"24px",overflow:"hidden",boxShadow:"0 12px 36px rgba(0,0,0,0.08)"},children:(0,i.jsx)(a.default,{src:"/wp-content/uploads/Lab-Grown Diamond/Lab-Grown Diamond 2.webp",alt:"Gemologist inspecting brilliant cut lab-grown diamond",fill:!0,style:{objectFit:"cover"},sizes:"(max-width: 900px) 50vw, 25vw"})})]})]})})}),(0,i.jsx)("section",{style:{backgroundColor:"#f6f4f0",padding:"90px 24px 100px"},children:(0,i.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:[(0,i.jsxs)("div",{style:{display:"flex",alignItems:"flex-end",justifyContent:"space-between",marginBottom:"40px",flexWrap:"wrap",gap:"16px"},children:[(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase",color:c,marginBottom:"8px"},children:"TIMELINE & INNOVATION"}),(0,i.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 3.8vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315",lineHeight:1.2},children:"Created with Science. Finished with Elegance."})]}),(0,i.jsxs)("div",{style:{display:"flex",gap:"10px"},children:[(0,i.jsx)("button",{type:"button",className:"timeline-nav-btn",onClick:()=>{l(e=>e>0?e-1:r.length-1)},"aria-label":"Previous step",children:"‹"}),(0,i.jsx)("button",{type:"button",className:"timeline-nav-btn",onClick:()=>{l(e=>e<r.length-1?e+1:0)},"aria-label":"Next step",children:"›"})]})]}),(0,i.jsxs)("div",{className:"timeline-track-wrap",children:[(0,i.jsx)("div",{className:"timeline-track-line"}),(0,i.jsx)("div",{className:"timeline-points-row",children:r.map((t,a)=>{let n=a===e;return(0,i.jsxs)("button",{type:"button",className:`timeline-point-btn${n?" active":""}`,onClick:()=>l(a),children:[(0,i.jsx)("span",{className:"timeline-point-year",children:t.year}),(0,i.jsx)("span",{className:"timeline-point-dot"}),(0,i.jsx)("span",{style:{fontSize:"11px",color:n?"#111111":"#888888",fontWeight:n?700:500,textTransform:"uppercase",letterSpacing:"0.5px",marginTop:"2px"},children:t.label})]},t.year)})})]}),(0,i.jsxs)("div",{className:"timeline-card-split",style:{display:"flex",gap:"44px",alignItems:"center",backgroundColor:"#ffffff",borderRadius:"24px",padding:"40px",boxShadow:"0 8px 30px rgba(0,0,0,0.05)"},children:[(0,i.jsx)("div",{style:{position:"relative",flex:1,minHeight:"340px",borderRadius:"18px",overflow:"hidden"},children:(0,i.jsx)(a.default,{src:d.img,alt:d.title,fill:!0,style:{objectFit:"cover"},sizes:"(max-width: 900px) 100vw, 50vw"})}),(0,i.jsxs)("div",{style:{flex:1},children:[(0,i.jsx)("div",{style:{fontSize:"38px",fontWeight:800,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:c,lineHeight:1,marginBottom:"10px"},children:d.year}),(0,i.jsx)("div",{style:{fontSize:"11px",letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:700,color:"#777777",marginBottom:"10px"},children:d.subtitle}),(0,i.jsx)("h3",{style:{margin:"0 0 16px",fontSize:"24px",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315",lineHeight:1.3},children:d.title}),(0,i.jsx)("p",{style:{fontSize:"15px",lineHeight:1.8,color:"#555555",margin:"0 0 24px"},children:d.description}),(0,i.jsxs)("div",{style:{display:"flex",gap:"14px",flexWrap:"wrap"},children:[(0,i.jsx)(n.default,{href:"/diamonds",style:{display:"inline-block",padding:"12px 28px",backgroundColor:"#111111",color:"#ffffff",fontSize:"12px",fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",textDecoration:"none",borderRadius:"6px"},children:"Explore Diamonds"}),(0,i.jsx)(n.default,{href:"/create-your-own",style:{display:"inline-block",padding:"12px 28px",border:"1.5px solid #111111",color:"#111111",fontSize:"12px",fontWeight:700,letterSpacing:"1.5px",textTransform:"uppercase",textDecoration:"none",borderRadius:"6px"},children:"Create Your Own"})]})]})]})]})}),(0,i.jsx)("section",{style:{backgroundColor:"#ffffff",padding:"90px 24px"},children:(0,i.jsxs)("div",{style:{maxWidth:"1000px",margin:"0 auto",textAlign:"center"},children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase",color:c,marginBottom:"12px"},children:"REAL DIAMONDS, REAL SCIENCE"}),(0,i.jsx)("h2",{style:{margin:"0 0 24px",fontSize:"clamp(28px, 4vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315"},children:"What Are Lab-Grown Diamonds?"}),(0,i.jsxs)("p",{style:{fontSize:"16px",lineHeight:1.85,color:"#555555",margin:"0 0 16px"},children:["Lab-grown diamonds are ",(0,i.jsx)("strong",{style:{color:"#111111"},children:"real diamonds"})," created in highly controlled laboratory environments using advanced technological processes that replicate natural mantle pressure and heat."]}),(0,i.jsx)("p",{style:{fontSize:"15px",lineHeight:1.85,color:"#666666",margin:"0 0 32px"},children:"Unlike diamond simulants such as cubic zirconia or moissanite, lab-grown diamonds have the exact same fundamental chemical composition, crystal structure, and physical properties as natural diamonds. They are available in a beautiful range of shapes, sizes, and colours, making them an excellent choice for engagement rings, necklaces, earrings, and other fine jewellery."})]})}),(0,i.jsx)("section",{style:{backgroundColor:"#f6f4f0",padding:"90px 24px 100px"},children:(0,i.jsxs)("div",{style:{maxWidth:"1200px",margin:"0 auto"},children:[(0,i.jsxs)("div",{style:{textAlign:"center",marginBottom:"56px"},children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase",color:c,marginBottom:"10px"},children:"KEY BENEFITS"}),(0,i.jsx)("h2",{style:{margin:0,fontSize:"clamp(28px, 3.8vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315"},children:"Why Choose Lab-Grown Diamonds?"})]}),(0,i.jsx)("div",{className:"reasons-grid-3col",style:{display:"grid",gridTemplateColumns:"repeat(3, 1fr)",gap:"24px"},children:o.map(e=>(0,i.jsxs)("div",{className:"reason-card",children:[(0,i.jsxs)("span",{className:"reason-num",children:[e.number,"."]}),(0,i.jsx)("h3",{className:"reason-title",children:e.title}),(0,i.jsx)("p",{className:"reason-desc",children:e.description})]},e.number))})]})}),(0,i.jsx)("section",{style:{backgroundColor:"#ffffff",padding:"90px 24px 100px"},children:(0,i.jsxs)("div",{style:{maxWidth:"1050px",margin:"0 auto"},children:[(0,i.jsxs)("div",{style:{textAlign:"center",marginBottom:"48px"},children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase",color:c,marginBottom:"10px"},children:"SIDE BY SIDE"}),(0,i.jsx)("h2",{style:{margin:"0 0 16px",fontSize:"clamp(28px, 3.8vw, 42px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#0C1315"},children:"Lab-Grown Diamonds vs. Natural Diamonds"}),(0,i.jsx)("p",{style:{fontSize:"15px",color:"#666666",maxWidth:"640px",margin:"0 auto",lineHeight:1.7},children:"Both are real diamonds, sharing the same essential physical, chemical, and optical properties. The primary difference is their origin."})]}),(0,i.jsx)("div",{style:{overflowX:"auto"},children:(0,i.jsxs)("table",{className:"comp-table",children:[(0,i.jsx)("thead",{children:(0,i.jsxs)("tr",{children:[(0,i.jsx)("th",{style:{width:"28%"},children:"Feature"}),(0,i.jsx)("th",{style:{width:"36%",color:c},children:"Lab-Grown Diamonds"}),(0,i.jsx)("th",{style:{width:"36%"},children:"Natural Diamonds"})]})}),(0,i.jsx)("tbody",{children:s.map(e=>(0,i.jsxs)("tr",{children:[(0,i.jsx)("td",{children:(0,i.jsx)("strong",{children:e.feature})}),(0,i.jsx)("td",{style:{color:"#111111",fontWeight:600},children:e.lab}),(0,i.jsx)("td",{children:e.natural})]},e.feature))})]})})]})}),(0,i.jsxs)("section",{style:{position:"relative",backgroundColor:"#0a0a0a",color:"#ffffff",padding:"100px 24px",textAlign:"center",overflow:"hidden"},children:[(0,i.jsx)("div",{style:{position:"absolute",inset:0,background:"radial-gradient(ellipse at 50% 50%, rgba(191,163,124,0.14) 0%, transparent 70%)",pointerEvents:"none"}}),(0,i.jsxs)("div",{style:{position:"relative",zIndex:2,maxWidth:"850px",margin:"0 auto"},children:[(0,i.jsx)("div",{style:{fontSize:"12px",fontWeight:700,letterSpacing:"2.5px",textTransform:"uppercase",color:c,marginBottom:"16px"},children:"THE CARITAS PROMISE"}),(0,i.jsx)("h2",{style:{margin:"0 0 20px",fontSize:"clamp(32px, 4.5vw, 48px)",fontWeight:700,fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)',color:"#ffffff",lineHeight:1.2},children:"A More Beautiful Way to Celebrate"}),(0,i.jsx)("p",{style:{fontSize:"16.5px",lineHeight:1.8,color:"rgba(255,255,255,0.75)",margin:"0 auto 16px",maxWidth:"720px"},children:"Whether you are choosing an engagement ring, celebrating an anniversary, or simply treating yourself to something special, Caritas Luxury brings you a world of extraordinary diamond jewellery."}),(0,i.jsx)("p",{style:{fontSize:"15px",color:"rgba(255,255,255,0.6)",margin:"0 auto 36px",maxWidth:"640px"},children:"Because luxury should feel beautiful in every way."}),(0,i.jsx)("div",{style:{fontSize:"15px",fontWeight:600,letterSpacing:"1px",color:"#ffffff",marginBottom:"36px",fontFamily:'var(--title-fonts, "Readex Pro", sans-serif)'},children:"Discover the brilliance. Experience the difference. Choose Caritas."}),(0,i.jsx)(n.default,{href:"/shop",style:{display:"inline-block",padding:"16px 44px",backgroundColor:c,color:"#ffffff",fontSize:"13px",fontWeight:800,letterSpacing:"2px",textTransform:"uppercase",textDecoration:"none",borderRadius:"6px",boxShadow:"0 8px 24px rgba(191,163,124,0.3)",transition:"transform 0.2s ease, background-color 0.2s ease"},children:"EXPLORE OUR COLLECTION"})]})]})]})}])},2187,e=>{e.v(i=>Promise.all(["static/chunks/07-ep6xoj9ugp.js","static/chunks/3-4fx5fl93mcz.js","static/chunks/0a29h93bbbpv2.js"].map(i=>e.l(i))).then(()=>i(21551)))},43414,e=>{e.v(i=>Promise.all(["static/chunks/0a29h93bbbpv2.js","static/chunks/3-4fx5fl93mcz.js"].map(i=>e.l(i))).then(()=>i(60664)))},27510,e=>{e.v(i=>Promise.all(["static/chunks/3sbmzr8x4wmgj.js","static/chunks/3-4fx5fl93mcz.js"].map(i=>e.l(i))).then(()=>i(48323)))}]);